#!/bin/bash
# LDAPDomainDump 域信息转储脚本

DC_IP="192.168.1.10"
DOMAIN="corp.local"
USER="corp\\administrator"
PASS="Password123!"
OUTPUT_DIR="./ldap_dump"

mkdir -p ${OUTPUT_DIR}

echo "[*] 开始转储域信息: ${DOMAIN}"

# 转储所有域信息
ldapdomaindump \
    -u "${USER}" \
    -p "${PASS}" \
    --no-json \
    -o ${OUTPUT_DIR} \
    ${DC_IP}

echo "[*] 转储完成，结果保存至: ${OUTPUT_DIR}"
echo "[*] 生成的文件："
ls -la ${OUTPUT_DIR}

# 查看域用户
echo ""
echo "[*] 域用户列表（前20条）："
cat ${OUTPUT_DIR}/domain_users.grep 2>/dev/null | head -20
