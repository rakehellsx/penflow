<?php
/*
 * Neo-reGeorg Tunnel Shell
 * 生成命令：python3 neoreg.py generate -k penflow_test_key
 * 上传此文件到目标 Web 服务器后，执行：
 * python3 neoreg.py -k penflow_test_key -u http://target.com/tunnel.php
 */

// 此处为 Neo-reGeorg 生成的混淆 PHP 代码占位
// 实际使用时请用 neoreg.py generate 命令生成真实文件
$_SESSION['key'] = 'penflow_test_key';
echo "Neo-reGeorg tunnel placeholder - generate real file with neoreg.py";
?>
