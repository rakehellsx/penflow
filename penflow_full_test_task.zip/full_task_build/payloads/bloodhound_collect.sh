#!/bin/bash
# BloodHound 数据采集脚本

DC_IP="192.168.1.10"
DOMAIN="corp.local"
USER="lowpriv_user"
PASS="Password123!"
OUTPUT_DIR="./bloodhound_data"

mkdir -p ${OUTPUT_DIR}

echo "[*] 方式一：使用 bloodhound-python 远程采集（无需上传文件到目标）"
bloodhound-python \
    -d ${DOMAIN} \
    -u ${USER} \
    -p ${PASS} \
    -ns ${DC_IP} \
    -c All \
    --zip \
    -o ${OUTPUT_DIR}

echo "[*] 方式二：使用 SharpHound（在目标 Windows 机器上执行）"
echo "    上传 SharpHound.exe 到目标机器，然后执行："
echo "    SharpHound.exe -c All --zipfilename bloodhound_data.zip"
echo "    下载 bloodhound_data.zip 后导入 BloodHound GUI"

echo ""
echo "[*] 数据采集完成，导入 BloodHound："
echo "    1. 启动 Neo4j：neo4j start"
echo "    2. 启动 BloodHound GUI"
echo "    3. 拖拽 zip 文件到 BloodHound 界面导入"
echo "    4. 查询攻击路径：Find Shortest Paths to Domain Admins"
ls -lh ${OUTPUT_DIR}/
