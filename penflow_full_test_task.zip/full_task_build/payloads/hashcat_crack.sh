#!/bin/bash
# Hashcat GPU 哈希破解脚本

HASH_FILE="hashes.txt"
WORDLIST="/usr/share/wordlists/rockyou.txt"
RULES="/usr/share/hashcat/rules/best64.rule"
OUTPUT="cracked.txt"

# 示例哈希文件内容（NTLM 格式）
cat > ${HASH_FILE} << 'EOF'
8846f7eaee8fb117ad06bdd830b7586c
31d6cfe0d16ae931b73c59d7e0c089c0
EOF

echo "[*] 破解 NTLM 哈希（字典攻击）"
hashcat -m 1000 ${HASH_FILE} ${WORDLIST} -o ${OUTPUT}

echo "[*] 破解 NTLM 哈希（字典+规则）"
# hashcat -m 1000 ${HASH_FILE} ${WORDLIST} -r ${RULES} -o ${OUTPUT}

echo "[*] 破解 Net-NTLMv2 哈希（Responder 捕获）"
# hashcat -m 5600 netntlmv2_hashes.txt ${WORDLIST} -o ${OUTPUT}

echo "[*] 破解 Kerberos TGS 票据（Kerberoasting）"
# hashcat -m 13100 tgs_hashes.txt ${WORDLIST} -o ${OUTPUT}

echo "[*] 查看已破解结果"
hashcat -m 1000 ${HASH_FILE} --show
