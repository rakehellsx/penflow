#!/bin/bash
# Fscan 内网扫描脚本

TARGET="192.168.1.0/24"
OUTPUT="fscan_result.txt"

echo "[*] 开始扫描目标网段: ${TARGET}"

# 全功能扫描（端口+漏洞+弱口令）
./fscan -h ${TARGET} -o ${OUTPUT}

# 仅端口扫描（速度更快）
# ./fscan -h ${TARGET} -np -nopoc -o ${OUTPUT}

# 指定端口扫描
# ./fscan -h ${TARGET} -p 22,80,443,445,1433,3306,3389,6379,8080,8443 -o ${OUTPUT}

# 扫描单个 IP
# ./fscan -h 192.168.1.1 -o ${OUTPUT}

echo "[*] 扫描完成，结果保存至: ${OUTPUT}"
cat ${OUTPUT}
