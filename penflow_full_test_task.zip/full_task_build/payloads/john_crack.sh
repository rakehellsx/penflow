#!/bin/bash
# John the Ripper 哈希破解脚本

HASH_FILE="hashes.txt"
WORDLIST="/usr/share/wordlists/rockyou.txt"

# 示例哈希文件
cat > ${HASH_FILE} << 'EOF'
administrator:500:aad3b435b51404eeaad3b435b51404ee:8846f7eaee8fb117ad06bdd830b7586c:::
guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
EOF

echo "[*] 字典攻击破解 NTLM 哈希"
john --format=NT --wordlist=${WORDLIST} ${HASH_FILE}

echo "[*] 查看已破解结果"
john --show --format=NT ${HASH_FILE}

echo "[*] 破解 /etc/shadow（Linux）"
# unshadow /etc/passwd /etc/shadow > combined.txt
# john --wordlist=${WORDLIST} combined.txt

echo "[*] 破解 Net-NTLMv2（Responder 捕获）"
# john --format=netntlmv2 --wordlist=${WORDLIST} netntlmv2.txt
