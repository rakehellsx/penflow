#!/bin/bash
# Nmap 精细扫描脚本

TARGET="192.168.1.0/24"
OUTPUT_PREFIX="nmap_result"

echo "[*] 第一步：快速存活探测"
nmap -sn ${TARGET} -oG ${OUTPUT_PREFIX}_alive.txt

echo "[*] 第二步：全端口扫描（存活主机）"
nmap -p- --min-rate 5000 -T4 ${TARGET} -oN ${OUTPUT_PREFIX}_ports.txt

echo "[*] 第三步：服务版本和脚本扫描"
nmap -sV -sC -p 22,80,443,445,1433,3306,3389,6379,8080,8443 \
     --script=vuln,auth,default \
     ${TARGET} \
     -oN ${OUTPUT_PREFIX}_detail.txt \
     -oX ${OUTPUT_PREFIX}_detail.xml

echo "[*] 扫描完成"
