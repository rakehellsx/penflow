#!/bin/bash
# NBTScan NetBIOS 扫描脚本

TARGET="192.168.1.0/24"

echo "[*] NBTScan 扫描目标网段: ${TARGET}"

# 基础扫描
nbtscan ${TARGET}

# 详细输出（包含 MAC 地址）
nbtscan -v ${TARGET}

# 指定超时时间（毫秒）
# nbtscan -t 2000 ${TARGET}

echo "[*] 扫描完成"
