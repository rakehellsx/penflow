## 📦 载荷使用说明：hashcat_crack.sh

该载荷文件主要配合 **Hashcat** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Hashcat` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
# 破解 NTLM
hashcat -m 1000 hashes.txt rockyou.txt

# 规则攻击
hashcat -m 1000 hashes.txt rockyou.txt \\
  -r rules/best64.rule

# NTLMv2 破解
hashcat -m 5600 ntlmv2.txt rockyou.txt
```

**配置示例 2**：
```bash
-m 1000  NTLM
-m 5600  NetNTLMv2
-m 13100 Kerberoast (TGS)
-m 18200 AS-REP Roasting
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Hashcat GPU哈希破解

### NTLM Hash 破解
```bash
# 破解 NTLM
hashcat -m 1000 hashes.txt rockyou.txt

# 规则攻击
hashcat -m 1000 hashes.txt rockyou.txt \\
  -r rules/best64.rule

# NTLMv2 破解
hashcat -m 5600 ntlmv2.txt rockyou.txt
```

### 常用模式
```
-m 1000  NTLM
-m 5600  NetNTLMv2
-m 13100 Kerberoast (TGS)
-m 18200 AS-REP Roasting
```

- ✓ GPU 加速，速度极快
- 配合 wordlist + rules 效果最佳