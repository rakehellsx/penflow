## 📦 载荷使用说明：proxychains.conf

该载荷文件主要配合 **Proxychains** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Proxychains` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
[ProxyList]
socks5  127.0.0.1  1080
```

**配置示例 2**：
```bash
# 通过代理运行任意命令
proxychains4 nmap -sT -Pn 192.168.1.50
proxychains4 curl http://internal.target.com
proxychains4 ssh user@192.168.1.100
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Proxychains 代理链配置

### 配置文件 (/etc/proxychains4.conf)
```
[ProxyList]
socks5  127.0.0.1  1080
```

### 使用方法
```bash
# 通过代理运行任意命令
proxychains4 nmap -sT -Pn 192.168.1.50
proxychains4 curl http://internal.target.com
proxychains4 ssh user@192.168.1.100
```

- ✓ 透明代理，无需修改工具
- ⚠ 不支持 UDP/ICMP
- 配合 FRP/Chisel 使用效果最佳