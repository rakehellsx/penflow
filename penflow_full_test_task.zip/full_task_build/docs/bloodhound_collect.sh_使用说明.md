## 📦 载荷使用说明：bloodhound_collect.sh

该载荷文件主要配合 **BloodHound** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `BloodHound` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
# Windows 上运行
SharpHound.exe -c All

# Python 版本
python3 bloodhound.py -u user -p Pass123 \\
  -d corp.local -ns 192.168.1.10
```

**配置示例 2**：
```bash
# 启动 Neo4j
neo4j start

# 启动 BloodHound GUI
bloodhound
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## BloodHound AD攻击路径分析

### 数据收集 (SharpHound)
```bash
# Windows 上运行
SharpHound.exe -c All

# Python 版本
python3 bloodhound.py -u user -p Pass123 \\
  -d corp.local -ns 192.168.1.10
```

### 启动 BloodHound
```bash
# 启动 Neo4j
neo4j start

# 启动 BloodHound GUI
bloodhound
```

- ✓ 可视化 AD 攻击路径
- 自动发现 Kerberoastable 账户
- 识别 DCSync 权限路径