## 📦 载荷使用说明：john_crack.sh

该载荷文件主要配合 **John the Ripper** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `John the Ripper` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
# 自动识别格式
john hashes.txt

# 指定字典
john --wordlist=rockyou.txt hashes.txt

# NTLM 格式
john --format=NT hashes.txt --wordlist=rockyou.txt

# 查看破解结果
john --show hashes.txt
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## John the Ripper 哈希破解

### 基本破解
```bash
# 自动识别格式
john hashes.txt

# 指定字典
john --wordlist=rockyou.txt hashes.txt

# NTLM 格式
john --format=NT hashes.txt --wordlist=rockyou.txt

# 查看破解结果
john --show hashes.txt
```

- CPU 破解，速度较 Hashcat 慢
- ✓ 自动识别 Hash 类型
- 支持增量模式暴力破解