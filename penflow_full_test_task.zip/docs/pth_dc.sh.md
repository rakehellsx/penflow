## 📦 载荷使用说明：pth_dc.sh

### 📝 功能说明
针对域控制器的哈希传递（Pass-the-Hash）自动化攻击脚本，通常组合使用 WMIExec 或 SecretsDump，利用获取到的高权限账户 Hash 直接控制域控。

### ⚙️ 参数说明
```text
- `domain/admin_user@dc_ip`：域管理员账户和域控 IP
- `-hashes`：管理员的 NTLM Hash
```

### 🚀 操作步骤
1. 获取域管理员（Domain Admins）的 NTLM Hash。
2. 修改脚本中的账户、域控 IP 和 Hash 信息。
3. 执行脚本：`bash pth_dc.sh`。
4. 获取域控的命令行权限，或直接导出域内所有 Hash。
