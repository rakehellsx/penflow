## 📦 载荷使用说明：kerberoasting.sh

### 📝 功能说明
利用 Kerberos 协议设计的特性，请求服务主体名称（SPN）的 TGS 票据，并将其导出以进行离线暴力破解，从而获取服务账户的明文密码。

### ⚙️ 参数说明
```text
- `domain/username:password`：用于请求票据的普通域用户凭据
- `-request`：请求所有可用的 SPN 票据
- `-dc-ip`：域控制器 IP 地址
- `-outputfile`：保存提取到的哈希的文件路径
```

### 🚀 操作步骤
1. 获取一个普通的域用户凭据。
2. 修改脚本中的域信息、凭据和域控 IP。
3. 执行脚本：`bash kerberoasting.sh`。
4. 脚本会将提取到的 TGS 票据哈希保存到指定文件。
5. 使用 Hashcat（`-m 13100`）或 John the Ripper 对提取的哈希进行离线破解。
