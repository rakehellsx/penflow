### John the Ripper

| 属性 | 值 |
|------|-----|
| 版本 | 1.9.0 |
| 平台 | 跨平台 |
| 风险 | 🟡 低 |
| 标签 | `密码破解` `离线分析` |

## John 离线密码破解

### 破解 NTLM Hash
```bash
bash john_crack.sh --format=NT --wordlist=rockyou.txt hashes.txt
```

### 破解 Linux Shadow 密码
```bash
bash john_crack.sh --wordlist=rockyou.txt shadow.txt
```

### 查看已破解的密码
```bash
john --show hashes.txt
```

- ✓ 强大的规则和变异引擎
- ✓ 自动识别 Hash 格式
- 适合 CPU 环境下的高效破解
