## 📦 载荷使用说明：john_crack.sh

### 📝 功能说明
一款强大的离线密码破解工具。此脚本用于破解系统密码哈希（如 Linux 的 /etc/shadow 或 Windows 的 SAM/NTLM）。

### ⚙️ 参数说明
```text
- `--format`：指定哈希格式（如 `NT`）
- `--wordlist`：指定密码字典文件
- `hash_file`：包含待破解哈希的文件路径
```

### 🚀 操作步骤
1. 收集目标系统的密码哈希文件。
2. 修改脚本中的哈希格式和字典路径。
3. 执行脚本：`bash john_crack.sh`。
4. 破解过程中按任意键可查看进度。
5. 破解完成后，使用 `john --show hash_file` 查看破解出的明文密码。

### 💻 执行样例
```bash
# 破解 NTLM Hash
./john_crack.sh --format=NT --wordlist=rockyou.txt hashes.txt

# 预期输出：
# Using default input encoding: UTF-8
# Loaded 1 password hash (NT [MD4 128/128 AVX 4x3])
# password123      (?)
# 1g 0:00:00:00 DONE (2023-10-24 12:00) 100.0g/s 1433Kp/s 1433Kc/s 1433KC/s 123456..123456789
```
