## 📦 载荷使用说明：proxychains.conf

### 📝 功能说明
代理链配置文件，强制任何指定的命令行程序通过配置文件中定义的代理服务器（如 SOCKS5）发起网络连接，实现内网工具的透明代理。

### ⚙️ 参数说明
```text
- `strict_chain` / `dynamic_chain`：代理链模式
- `[ProxyList]`：代理服务器列表配置，格式为 `协议 IP 端口`（如 `socks5 127.0.0.1 1080`）
```

### 🚀 操作步骤
1. 通过 FRP 或 Chisel 等工具建立内网 SOCKS5 代理。
2. 修改此配置文件，在 `[ProxyList]` 末尾添加建立的代理地址和端口。
3. 使用 ProxyChains 运行渗透工具：`proxychains4 nmap -sT -Pn 192.168.1.100`。
4. 工具的流量将自动通过代理隧道转发到内网。
