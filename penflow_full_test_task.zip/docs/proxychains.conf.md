## 📦 载荷使用说明：proxychains.conf

### 📝 功能说明
代理链配置文件，强制任何指定的命令行程序通过配置文件中定义的代理服务器（如 SOCKS5）发起网络连接，实现内网工具的透明代理。

### ⚙️ 参数说明
```text
- `strict_chain` / `dynamic_chain`：代理链模式
- `[ProxyList]`：代理服务器列表配置，格式为 `协议 IP 端口`（如 `socks5 127.0.0.1 1080`）
```

### 🚀 操作步骤
1. 通过 FRP 或 Chisel 等工具建立内网 SOCKS5 代理。
2. 修改此配置文件，在 `[ProxyList]` 末尾添加建立的代理地址和端口。
3. 使用 ProxyChains 运行渗透工具：`proxychains4 nmap -sT -Pn 192.168.1.100`。
4. 工具的流量将自动通过代理隧道转发到内网。

### 💻 执行样例
```ini
# proxychains.conf 示例
strict_chain
proxy_dns
remote_dns_subnet 224
tcp_read_time_out 15000
tcp_connect_time_out 8000

[ProxyList]
# add proxy here ...
# meanwile
# defaults set to "tor"
socks5  127.0.0.1 1080

# 运行命令：
# proxychains4 -f proxychains.conf nmap -sT -Pn 192.168.1.10
# 预期输出：
# [proxychains] config file found: proxychains.conf
# [proxychains] preloading /usr/lib/x86_64-linux-gnu/libproxychains.so.4
# [proxychains] DLL init: proxychains-ng 4.14
# Starting Nmap 7.93 ( https://nmap.org ) at 2023-10-24 12:00 UTC
# [proxychains] Strict chain  ...  127.0.0.1:1080  ...  192.168.1.10:445  ...  OK
```
