## 📦 载荷使用说明：bloodhound_collect.sh

### 📝 功能说明
用于在活动目录（Active Directory）环境中收集域内对象关系数据（如用户、组、计算机、GPO 等），以供 BloodHound 进行图论分析和攻击路径推演。

### ⚙️ 参数说明
```text
- `-d`：指定目标域名（如 `contoso.com`）
- `-u`：指定域用户名
- `-p`：指定用户密码
- `-c`：收集的数据类型，通常为 `All`（收集所有信息）
- `-dc`：指定域控制器 IP 地址
```

### 🚀 操作步骤
1. 将此脚本上传至已攻陷的内网主机。
2. 赋予脚本执行权限：`chmod +x bloodhound_collect.sh`。
3. 修改脚本内的域名、用户名和密码参数。
4. 执行脚本，生成的 JSON 或 ZIP 文件将保存在当前目录。
5. 将生成的数据文件下载到本地，导入 BloodHound 进行分析。

### 💻 执行样例
```bash
# 收集 contoso.com 域的所有信息
./bloodhound_collect.sh -d contoso.com -u testuser -p Password123! -c All -dc 192.168.1.10

# 预期输出：
# [*] Starting BloodHound collection...
# [+] Found 150 users, 50 computers, 20 groups.
# [+] Collection finished. Data saved to 20231024120000_BloodHound.zip.
```
