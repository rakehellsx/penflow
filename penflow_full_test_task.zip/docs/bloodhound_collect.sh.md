### BloodHound (SharpHound)

| 属性 | 值 |
|------|-----|
| 版本 | 4.x |
| 平台 | Windows/Linux |
| 风险 | 🔴 高 |
| 标签 | `AD` `信息收集` `图论分析` |

## BloodHound 数据收集

### 收集所有域信息
```bash
bash bloodhound_collect.sh -d contoso.com -u testuser -p Password123! -c All -dc 192.168.1.10
```

### 仅收集 Session 和本地管理员信息
```bash
bash bloodhound_collect.sh -d contoso.com -u testuser -p Password123! -c Session,LocalAdmin -dc 192.168.1.10
```

### 导出为 ZIP 格式以供离线分析
```bash
bash bloodhound_collect.sh -d contoso.com -u testuser -p Password123! -c All --zip
```

- ✓ 自动收集 AD 结构数据
- ✓ 支持细粒度收集类型
- 配合 BloodHound 界面分析攻击路径
