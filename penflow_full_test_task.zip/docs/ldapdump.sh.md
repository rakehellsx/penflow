### LDAPDomainDump

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.3 |
| 平台 | Linux |
| 风险 | 🟠 中 |
| 标签 | `AD枚举` `信息收集` `LDAP` |

## LDAP 域信息全量导出

### 导出域信息到指定目录
```bash
bash ldapdump.sh -u user1 -p Pass123 192.168.1.10 -o /tmp/ldap_dump
```

### 使用 NTLM Hash 认证
```bash
bash ldapdump.sh -u user1 -H :31d6cfe0d16ae931b73c59d7e0c089c0 192.168.1.10 -o /tmp/ldap_dump
```

### 查看生成的 HTML 报告
```bash
xdg-open /tmp/ldap_dump/domain_users.html
```

- ✓ 生成直观的 HTML 报告
- ✓ 包含用户、组、计算机、策略等全面信息
- 仅需普通域用户权限
