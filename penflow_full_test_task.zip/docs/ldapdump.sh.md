## 📦 载荷使用说明：ldapdump.sh

### 📝 功能说明
通过 LDAP 协议连接到域控制器，导出活动目录中的所有用户、计算机、组、域策略等信息，生成 HTML/JSON/CSV 格式的报告。

### ⚙️ 参数说明
```text
- `-u`：域用户名
- `-p`：用户密码
- `dc_ip`：域控制器 IP 地址
- `-o`：输出目录
```

### 🚀 操作步骤
1. 获取任意一个有效的域用户凭据。
2. 修改脚本中的凭据和域控 IP。
3. 执行脚本：`bash ldapdump.sh`。
4. 脚本运行完成后，进入输出目录查看生成的 HTML 报告，分析域内结构和权限关系。

### 💻 执行样例
```bash
# 导出域信息到 /tmp/ldap_dump 目录
./ldapdump.sh -u user1 -p Pass123 192.168.1.10 -o /tmp/ldap_dump

# 预期输出：
# [*] Connecting to 192.168.1.10...
# [*] Binding as contoso.com\user1
# [*] Dumping domain info...
# [*] Dumping users...
# [*] Dumping groups...
# [*] Dumping computers...
# [+] Dump completed. HTML reports saved to /tmp/ldap_dump
```
