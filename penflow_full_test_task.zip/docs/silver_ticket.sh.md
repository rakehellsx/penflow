## 📦 载荷使用说明：silver_ticket.sh

### 📝 功能说明
用于伪造白银票据（Silver Ticket）的 Mimikatz 脚本。通过获取特定服务账户（如目标机器的计算机账户）的 NTLM Hash，伪造针对该特定服务的 TGS 票据，实现对该服务的隐蔽访问。

### ⚙️ 参数说明
```text
- `/domain`：目标域名
- `/sid`：域的 SID
- `/target`：目标主机的 FQDN（如 `server.contoso.com`）
- `/service`：目标服务名称（如 `cifs` 代表文件共享，`http` 代表 WinRM）
- `/rc4`：服务账户的 NTLM Hash
- `/user`：伪造的用户名
```

### 🚀 操作步骤
1. 获取目标机器的计算机账户 Hash 或特定服务账户 Hash。
2. 修改脚本中的域信息、目标主机、服务名称和 Hash。
3. 执行脚本生成白银票据，并使用 `kerberos::ptt` 注入内存。
4. 即可免密访问目标主机的指定服务（如通过 SMB 访问 C$ 共享）。
