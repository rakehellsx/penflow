## 📦 载荷使用说明：eternalblue_py.sh

### 📝 功能说明
基于 Python 实现的 MS17-010（永恒之蓝）漏洞利用脚本，用于向存在漏洞的 Windows 主机发送恶意 SMB 数据包，执行自定义的 Shellcode。

### ⚙️ 参数说明
```text
- `target_ip`：存在 MS17-010 漏洞的目标 IP 地址
- `shellcode_file`：要执行的恶意 Shellcode 二进制文件路径
```

### 🚀 操作步骤
1. 使用 msfvenom 生成反弹 Shell 的 Shellcode（如 raw 格式）。
2. 将生成的 Shellcode 和此利用脚本上传至攻击机。
3. 修改脚本中的目标 IP 和 Shellcode 文件路径。
4. 在本地启动监听（如 netcat 或 msfconsole）。
5. 执行利用脚本：`bash eternalblue_py.sh`，等待反弹 Shell。
