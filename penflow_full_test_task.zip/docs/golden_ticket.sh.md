## 📦 载荷使用说明：golden_ticket.sh

### 📝 功能说明
用于伪造域内黄金票据（Golden Ticket）的 Mimikatz 脚本。通过使用 krbtgt 账户的 NTLM Hash，攻击者可以伪造任意域用户的 TGT 票据，实现域内持久化控制。

### ⚙️ 参数说明
```text
- `/domain`：目标域名（FQDN）
- `/sid`：域的 SID（安全标识符）
- `/krbtgt`：krbtgt 账户的 NTLM Hash
- `/user`：要伪造的用户名（通常为 Administrator）
- `/ticket`：生成的票据保存路径（如 `golden.kirbi`）
```

### 🚀 操作步骤
1. 前提条件：已获取域的 SID 和 krbtgt 账户的 Hash（通常通过 DCSync 获取）。
2. 修改脚本中的域信息、SID 和 Hash 参数。
3. 在已攻陷的域内主机上以管理员权限执行此脚本。
4. 生成 `golden.kirbi` 票据文件。
5. 使用 Mimikatz 的 `kerberos::ptt` 命令将票据注入内存，即可访问域控。
