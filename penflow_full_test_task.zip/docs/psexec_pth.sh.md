## 📦 载荷使用说明：psexec_pth.sh

### 📝 功能说明
Impacket 版本的 PsExec 工具，利用 SMB 协议在目标 Windows 主机上创建服务并执行命令。支持使用 NTLM Hash 进行哈希传递登录，无需明文密码。

### ⚙️ 参数说明
```text
- `domain/username@target_ip`：目标域、用户名和 IP 地址
- `-hashes`：NTLM Hash，格式为 `LM_Hash:NT_Hash`（如果只有 NT Hash，LM 部分用 0 填充，如 `00000000000000000000000000000000:NT_Hash`）
```

### 🚀 操作步骤
1. 确认目标主机开放了 445 端口（SMB），且当前凭据具有管理员权限。
2. 修改脚本中的目标信息和 NTLM Hash。
3. 执行脚本：`bash psexec_pth.sh`。
4. 成功连接后，将获得目标主机的 SYSTEM 权限交互式 Shell。
