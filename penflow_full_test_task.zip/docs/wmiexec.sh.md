## 📦 载荷使用说明：wmiexec.sh

### 📝 功能说明
Impacket 工具集中的远程命令执行工具。利用 WMI（Windows 管理规范）协议在目标机器上执行命令，不接触磁盘，被杀毒软件拦截的概率极低。

### ⚙️ 参数说明
```text
- `domain/username:password@target_ip`：具有管理员权限的凭据和目标 IP
- `-hashes`：支持使用 Hash 替代明文密码
```

### 🚀 操作步骤
1. 确认目标主机开放了 135 端口（RPC）及动态端口，且凭据具有管理员权限。
2. 修改脚本中的目标信息和凭据。
3. 执行脚本：`bash wmiexec.sh`。
4. 获得一个半交互式的管理员权限 Shell。
