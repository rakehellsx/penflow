## 📦 载荷使用说明：tunnel.php

### 📝 功能说明
Neo-reGeorg 的 PHP 隧道脚本（WebShell）。将此脚本上传到目标 Web 服务器后，攻击者可以通过它建立正向的 SOCKS5 代理隧道，穿透防火墙访问内网。

### ⚙️ 参数说明
```text
- 无直接参数，需配置 Neo-reGeorg 客户端连接此脚本的 URL 和密码。
```

### 🚀 操作步骤
1. 利用 Web 漏洞（如文件上传、RCE）将 `tunnel.php` 上传至目标 Web 服务器的公共目录。
2. 确保可通过浏览器访问该脚本（显示空白或特定提示说明正常）。
3. 在攻击机启动 Neo-reGeorg 客户端：`python3 neoreg.py -k <password> -u http://target.com/tunnel.php`。
4. 客户端将在本地监听 SOCKS5 端口，配置 ProxyChains 使用该端口访问内网。
