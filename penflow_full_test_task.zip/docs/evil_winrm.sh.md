## 📦 载荷使用说明：evil_winrm.sh

### 📝 功能说明
基于 WinRM（Windows 远程管理）协议的终极 PowerShell 交互式 Shell 工具，常用于获取 Windows 主机的命令行访问权限，支持哈希传递登录。

### ⚙️ 参数说明
```text
- `-i`：目标 Windows 主机的 IP 地址
- `-u`：登录用户名
- `-p`：明文密码
- `-H`：NTLM Hash（用于 Pass-the-Hash）
```

### 🚀 操作步骤
1. 确认目标主机开放了 5985（HTTP）或 5986（HTTPS）端口，且 WinRM 服务已启用。
2. 根据已掌握的凭据（明文或 Hash），修改脚本参数。
3. 执行脚本：`bash evil_winrm.sh`。
4. 成功连接后，将获得一个交互式的 PowerShell 提示符。
