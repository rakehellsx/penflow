### Hashcat

| 属性 | 值 |
|------|-----|
| 版本 | 6.2.6 |
| 平台 | 跨平台 |
| 风险 | 🟡 低 |
| 标签 | `密码破解` `离线分析` |

## Hashcat 离线密码破解

### 破解 NTLM Hash (模式 1000)
```bash
bash hashcat_crack.sh -m 1000 -a 0 hashes.txt rockyou.txt
```

### 破解 Kerberos TGS (模式 13100)
```bash
bash hashcat_crack.sh -m 13100 -a 0 tgs_hashes.txt rockyou.txt
```

### 破解 NTLMv2 (模式 5600)
```bash
bash hashcat_crack.sh -m 5600 -a 0 ntlmv2_hashes.txt rockyou.txt
```

- ✓ 支持 GPU 硬件加速
- ✓ 支持数百种 Hash 算法
- 速度取决于字典质量和硬件性能
