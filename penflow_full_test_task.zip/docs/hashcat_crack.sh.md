## 📦 载荷使用说明：hashcat_crack.sh

### 📝 功能说明
世界上最快的密码破解工具。此脚本配置为使用字典模式破解获取到的 NTLM 或其他类型的密码哈希。

### ⚙️ 参数说明
```text
- `-m`：哈希类型（如 `1000` 代表 NTLM）
- `-a`：攻击模式（`0` 代表字典攻击）
- `hash_file`：包含待破解哈希的文件路径
- `wordlist`：用于破解的密码字典文件路径
```

### 🚀 操作步骤
1. 将获取到的哈希值保存为文本文件（如 `hashes.txt`）。
2. 准备好密码字典（如 `rockyou.txt`）。
3. 修改脚本中的哈希类型、哈希文件路径和字典路径。
4. 执行破解：`bash hashcat_crack.sh`。
5. 等待破解完成，查看输出的明文密码。

### 💻 执行样例
```bash
# 破解 NTLM Hash (模式 1000)
./hashcat_crack.sh -m 1000 -a 0 hashes.txt rockyou.txt

# 预期输出：
# 31d6cfe0d16ae931b73c59d7e0c089c0:password123
# 
# Session..........: hashcat
# Status...........: Cracked
# Hash.Mode........: 1000 (NTLM)
```
