### CrackMapExec

| 属性 | 值 |
|------|-----|
| 版本 | 5.4.0 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `SMB` `域枚举` `PTH` |

## CrackMapExec SMB枚举

### 扫描域内主机
```bash
bash crackmapexec_enum.sh 192.168.1.0/24

# 用户名密码验证
bash crackmapexec_enum.sh 192.168.1.0/24 -u admin -p Pass123
```

### Hash 传递 (Pass-the-Hash)
```bash
bash crackmapexec_enum.sh 192.168.1.0/24 -u admin -H aad3b435b51404eeaad3b435b51404ee:8846f7ea...
```

### 信息收集
```bash
bash crackmapexec_enum.sh 192.168.1.10 --users
bash crackmapexec_enum.sh 192.168.1.10 --groups
bash crackmapexec_enum.sh 192.168.1.10 --shares
```

- ✓ 支持 PTH 横向移动
- ✓ 可枚举域用户、组、共享
- 并发扫描速度快
