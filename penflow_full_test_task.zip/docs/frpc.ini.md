### FRP

| 属性 | 值 |
|------|-----|
| 版本 | 0.45.0 |
| 平台 | 跨平台 |
| 风险 | 🟠 中 |
| 标签 | `内网穿透` `代理` `端口映射` |

## FRP 客户端配置与启动

### 启动 FRP 客户端连接到服务端
```bash
./frpc -c frpc.ini
```

### 配置正向端口映射 (在 frpc.ini 中)
```bash
[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 3389
remote_port = 6000
```

### 配置 SOCKS5 代理 (在 frpc.ini 中)
```bash
[socks5]
type = tcp
remote_port = 1080
plugin = socks5
```

- ✓ 支持 TCP/UDP/HTTP/HTTPS 多种协议
- ✓ 稳定可靠的 SOCKS5 代理
- 适合建立长期后门隧道
