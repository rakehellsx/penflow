### NBTScan

| 属性 | 值 |
|------|-----|
| 版本 | 1.5.1 |
| 平台 | 跨平台 |
| 风险 | 🟠 中 |
| 标签 | `主机发现` `NetBIOS` `信息收集` |

## NBTScan 内网主机探测

### 扫描 C 段获取主机名和 MAC
```bash
bash nbtscan_scan.sh 192.168.1.0/24
```

### 扫描单个 IP
```bash
bash nbtscan_scan.sh 192.168.1.10
```

### 读取 IP 列表文件进行扫描
```bash
bash nbtscan_scan.sh -f ips.txt
```

- ✓ 快速识别 Windows 主机名和工作组/域
- ✓ 基于 NetBIOS 协议，无需高权限
- 帮助快速定位域控制器
