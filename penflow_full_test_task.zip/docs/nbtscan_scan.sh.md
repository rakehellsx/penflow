## 📦 载荷使用说明：nbtscan_scan.sh

### 📝 功能说明
基于 NetBIOS 协议的内网主机扫描工具，用于快速发现局域网内的 Windows 主机，获取其 NetBIOS 名称、MAC 地址和所在工作组/域。

### ⚙️ 参数说明
```text
- `target_range`：目标 IP 网段（如 `192.168.1.0/24`）
```

### 🚀 操作步骤
1. 将 NBTScan 二进制文件和此脚本上传至内网跳板机。
2. 修改脚本中的目标网段参数。
3. 执行扫描：`bash nbtscan_scan.sh`。
4. 查看输出结果，识别内网中的 Windows 资产和可能的域控制器。

### 💻 执行样例
```bash
# 扫描 192.168.1.0/24 网段
./nbtscan_scan.sh 192.168.1.0/24

# 预期输出：
# Doing NBT name scan for addresses from 192.168.1.0/24
# 
# IP address       NetBIOS Name     Server    User             MAC address      
# ------------------------------------------------------------------------------
# 192.168.1.10     DC01             <server>  <unknown>        00:11:22:33:44:55
# 192.168.1.20     PC01             <server>  USER1            00:11:22:33:44:66
```
