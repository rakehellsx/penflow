## 📦 载荷使用说明：nmap_scan.sh

### 📝 功能说明
网络探测和安全审核的行业标准工具。此脚本配置为进行精细的端口扫描、服务版本探测和操作系统识别。

### ⚙️ 参数说明
```text
- `-sV`：探测服务版本
- `-sC`：使用默认脚本扫描
- `-O`：操作系统探测
- `-p-`：扫描所有 65535 个端口（可选）
- `-T4`：设置较快的扫描速度
```

### 🚀 操作步骤
1. 修改脚本中的目标 IP 或网段。
2. 根据需要调整扫描参数（如端口范围）。
3. 执行脚本：`bash nmap_scan.sh`。
4. 分析扫描结果，识别开放端口、服务漏洞和操作系统类型。

### 💻 执行样例
```bash
# 扫描 192.168.1.10
./nmap_scan.sh 192.168.1.10

# 预期输出：
# Starting Nmap 7.93 ( https://nmap.org ) at 2023-10-24 12:00 UTC
# Nmap scan report for 192.168.1.10
# Host is up (0.0010s latency).
# Not shown: 995 closed tcp ports (reset)
# PORT     STATE SERVICE       VERSION
# 135/tcp  open  msrpc         Microsoft Windows RPC
# 139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
# 445/tcp  open  microsoft-ds  Windows Server 2016 Standard 14393 microsoft-ds (workgroup: CONTOSO)
# 3389/tcp open  ms-wbt-server Microsoft Terminal Services
# MAC Address: 00:11:22:33:44:55 (VMware)
# Device type: general purpose
# Running: Microsoft Windows 2016
# OS CPE: cpe:/o:microsoft:windows_server_2016
# OS details: Microsoft Windows Server 2016
# 
# Host script results:
# |_smb-os-discovery: Windows Server 2016 Standard 14393 (Windows Server 2016 Standard 6.3)
# |_smb-security-mode: account_used: guest, authentication_level: user, challenge_response: supported, message_signing: required
# 
# Nmap done: 1 IP address (1 host up) scanned in 15.23 seconds
```
